<?php
/**
 * Quick WordPress option test
 * Place this in your WordPress root and access via browser to test option functionality
 */

// Load WordPress
require_once dirname(__FILE__) . '/wp-config.php';
require_once dirname(__FILE__) . '/wp-load.php';

echo "<h2>WordPress Option System Test</h2>";

// Test 1: Basic option update
echo "<h3>Test 1: Basic Option Update</h3>";
$test_name = 'test_option_' . time();
$test_value = 'test_value_' . rand(1000, 9999);

$result = update_option($test_name, $test_value);
echo "<p><strong>Creating new option:</strong> $test_name = $test_value</p>";
echo "<p><strong>Result:</strong> " . ($result ? 'SUCCESS' : 'FAILED') . "</p>";

if ($result) {
    $retrieved = get_option($test_name);
    echo "<p><strong>Retrieved value:</strong> $retrieved</p>";
    echo "<p><strong>Values match:</strong> " . ($retrieved === $test_value ? 'YES' : 'NO') . "</p>";
}

// Test 2: Update with same value
echo "<h3>Test 2: Update with Same Value</h3>";
$result2 = update_option($test_name, $test_value);
echo "<p><strong>Updating with same value:</strong> $test_value</p>";
echo "<p><strong>Result:</strong> " . ($result2 ? 'SUCCESS' : 'FAILED (expected)') . "</p>";
echo "<p><em>Note: update_option() returns FALSE when value hasn't changed</em></p>";

// Test 3: Update with different value
echo "<h3>Test 3: Update with Different Value</h3>";
$new_value = 'new_value_' . rand(1000, 9999);
$result3 = update_option($test_name, $new_value);
echo "<p><strong>Updating with new value:</strong> $new_value</p>";
echo "<p><strong>Result:</strong> " . ($result3 ? 'SUCCESS' : 'FAILED') . "</p>";

// Test 4: EduBot specific options
echo "<h3>Test 4: EduBot School Name Test</h3>";
$current_school_name = get_option('edubot_school_name', 'NOT_SET');
echo "<p><strong>Current school name:</strong> '$current_school_name'</p>";

$test_school_name = 'Test School Name ' . time();
$result4 = update_option('edubot_school_name', $test_school_name);
echo "<p><strong>Setting test school name:</strong> '$test_school_name'</p>";
echo "<p><strong>Result:</strong> " . ($result4 ? 'SUCCESS' : 'FAILED') . "</p>";

if ($result4) {
    $retrieved_school = get_option('edubot_school_name');
    echo "<p><strong>Retrieved school name:</strong> '$retrieved_school'</p>";
    
    // Restore original value
    if ($current_school_name !== 'NOT_SET') {
        update_option('edubot_school_name', $current_school_name);
        echo "<p><strong>Restored original value:</strong> '$current_school_name'</p>";
    }
}

// Test 5: Database permissions
echo "<h3>Test 5: Database Info</h3>";
global $wpdb;
echo "<p><strong>Database name:</strong> " . DB_NAME . "</p>";
echo "<p><strong>Table prefix:</strong> " . $wpdb->prefix . "</p>";
echo "<p><strong>Last error:</strong> " . ($wpdb->last_error ?: 'None') . "</p>";

// Check if options table exists
$options_table = $wpdb->prefix . 'options';
$table_exists = $wpdb->get_var("SHOW TABLES LIKE '$options_table'");
echo "<p><strong>Options table exists:</strong> " . ($table_exists ? 'YES' : 'NO') . "</p>";

// Clean up test option
delete_option($test_name);
echo "<p><em>Test option cleaned up</em></p>";

echo "<hr>";
echo "<p><strong>Conclusion:</strong> If all tests pass except Test 2, the WordPress option system is working correctly.</p>";
?>
