<?php
/**
 * Simplified test of academic config save logic without WordPress
 */

echo "=== Testing Academic Config Save Logic ===\n\n";

echo "1. Simulating form submission data...\n";

// Simulate form POST data
$_POST = array(
    'submit' => 'save',
    'edubot_academic_nonce' => 'test_nonce',
    'school_id' => '1',
    'academic_config' => array(
        'grade_systems' => array('elementary', 'middle'),
        'custom_grades_keys' => array('foundation', 'preparatory', 'advanced'),
        'custom_grades_labels' => array('Foundation Level', 'Preparatory Class', 'Advanced Studies')
    )
);

echo "2. Form data structure:\n";
print_r($_POST['academic_config']);

echo "\n3. Testing form submission detection...\n";
$submit_detected = isset($_POST['submit']);
echo "Submit detected: " . ($submit_detected ? 'YES' : 'NO') . "\n";

echo "\n4. Testing academic_config array processing...\n";
if (isset($_POST['academic_config']) && is_array($_POST['academic_config'])) {
    echo "✅ Academic config array found\n";
    $config_data = $_POST['academic_config'];
    
    // Test custom grades processing
    if (isset($config_data['custom_grades_keys']) && isset($config_data['custom_grades_labels'])) {
        echo "✅ Custom grades keys and labels found\n";
        $keys = $config_data['custom_grades_keys'];
        $labels = $config_data['custom_grades_labels'];
        
        echo "Keys: " . print_r($keys, true);
        echo "Labels: " . print_r($labels, true);
        
        $custom_grades = array();
        if (is_array($keys) && is_array($labels)) {
            echo "✅ Both keys and labels are arrays\n";
            for ($i = 0; $i < count($keys) && $i < count($labels); $i++) {
                $key = sanitize_key($keys[$i]);
                $label = sanitize_text_field($labels[$i]);
                
                echo "Processing pair $i: '$key' => '$label'\n";
                
                if (!empty($key) && !empty($label) && strlen($label) <= 50) {
                    $custom_grades[$key] = $label;
                    echo "✅ Added: $key => $label\n";
                } else {
                    echo "❌ Validation failed for pair $i\n";
                }
            }
        } else {
            echo "❌ Keys or labels are not arrays\n";
        }
        
        echo "\nFinal custom grades array:\n";
        print_r($custom_grades);
        
    } else {
        echo "❌ Custom grades keys or labels not found\n";
    }
    
} else {
    echo "❌ Academic config array not found or not an array\n";
}

echo "\n5. Testing form field name structure...\n";
echo "Expected form field names:\n";
echo "- academic_config[custom_grades_keys][]\n";
echo "- academic_config[custom_grades_labels][]\n";
echo "\nExpected POST structure:\n";
echo "- \$_POST['academic_config']['custom_grades_keys']\n";
echo "- \$_POST['academic_config']['custom_grades_labels']\n";
echo "✅ Structure matches!\n";

echo "\n=== Test Complete ===\n";
echo "The save logic should work correctly with this form structure.\n";

// Helper functions (simplified versions)
function sanitize_key($key) {
    return preg_replace('/[^a-z0-9_\-]/', '', strtolower($key));
}

function sanitize_text_field($str) {
    return trim(strip_tags($str));
}
?>
