-- EduBot Pro Database Table Creation
-- Run this SQL to create the missing wp_edubot_security_log table
-- Modify the table prefix 'wp_' if your WordPress installation uses a different prefix

-- Create the security log table
CREATE TABLE IF NOT EXISTS `wp_edubot_security_log` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `site_id` bigint(20) NOT NULL,
    `event_type` varchar(100) NOT NULL,
    `ip_address` varchar(45) NOT NULL,
    `user_agent` text,
    `details` longtext,
    `severity` varchar(20) DEFAULT 'medium',
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `site_id` (`site_id`),
    KEY `event_type` (`event_type`),
    KEY `ip_address` (`ip_address`),
    KEY `created_at` (`created_at`),
    KEY `severity` (`severity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create visitor analytics table if missing
CREATE TABLE IF NOT EXISTS `wp_edubot_visitor_analytics` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `site_id` bigint(20) NOT NULL,
    `visitor_id` varchar(255) NOT NULL,
    `session_id` varchar(255) NOT NULL,
    `page_url` text NOT NULL,
    `referrer_url` text,
    `user_agent` text,
    `ip_address` varchar(45),
    `country` varchar(100),
    `city` varchar(100),
    `device_type` varchar(50),
    `browser` varchar(50),
    `os` varchar(50),
    `screen_resolution` varchar(20),
    `time_on_page` int(11) DEFAULT 0,
    `interactions_count` int(11) DEFAULT 0,
    `conversion_event` varchar(100),
    `utm_source` varchar(100),
    `utm_medium` varchar(100),
    `utm_campaign` varchar(100),
    `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `site_id` (`site_id`),
    KEY `visitor_id` (`visitor_id`),
    KEY `session_id` (`session_id`),
    KEY `timestamp` (`timestamp`),
    KEY `conversion_event` (`conversion_event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create visitors table if missing
CREATE TABLE IF NOT EXISTS `wp_edubot_visitors` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `site_id` bigint(20) NOT NULL,
    `visitor_id` varchar(255) NOT NULL,
    `email` varchar(255),
    `phone` varchar(20),
    `name` varchar(255),
    `first_visit` datetime DEFAULT CURRENT_TIMESTAMP,
    `last_activity` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `total_visits` int(11) DEFAULT 1,
    `total_time_spent` int(11) DEFAULT 0,
    `pages_visited` int(11) DEFAULT 0,
    `interactions_count` int(11) DEFAULT 0,
    `lead_score` int(11) DEFAULT 0,
    `status` varchar(50) DEFAULT 'anonymous',
    `is_returning` tinyint(1) DEFAULT 0,
    `marketing_source` varchar(100),
    `conversion_status` varchar(50) DEFAULT 'none',
    `notes` longtext,
    `custom_data` longtext,
    PRIMARY KEY (`id`),
    UNIQUE KEY `visitor_id` (`visitor_id`, `site_id`),
    KEY `site_id` (`site_id`),
    KEY `email` (`email`),
    KEY `status` (`status`),
    KEY `is_returning` (`is_returning`),
    KEY `last_activity` (`last_activity`),
    KEY `marketing_source` (`marketing_source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Verify tables were created
SELECT 
    TABLE_NAME,
    TABLE_ROWS,
    CREATE_TIME
FROM 
    INFORMATION_SCHEMA.TABLES 
WHERE 
    TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME LIKE '%edubot%'
ORDER BY 
    TABLE_NAME;
