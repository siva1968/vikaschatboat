<?php
/**
 * Test the new hybrid OpenAI + Rule-based system
 * Run this to verify the chatbot routing logic
 */

// Include WordPress functions
require_once __DIR__ . '/../../../wp-config.php';
require_once __DIR__ . '/includes/class-edubot-autoloader.php';

// Initialize autoloader
EduBot_Autoloader::init();

echo "🤖 **EduBot Hybrid System Test**\n";
echo "================================\n\n";

// Test cases for routing logic
$test_cases = array(
    // Should use RULE-BASED system
    array(
        'message' => 'admission',
        'expected' => 'RULE-BASED',
        'reason' => 'Explicit admission request'
    ),
    array(
        'message' => 'Grade 1 CBSE 2025-26',
        'expected' => 'RULE-BASED',
        'reason' => 'Structured grade + board + year'
    ),
    array(
        'message' => 'Name: John, Email: john@email.com, Phone: 9876543210',
        'expected' => 'RULE-BASED',
        'reason' => 'Personal information with email/phone'
    ),
    array(
        'message' => 'confirm',
        'expected' => 'RULE-BASED',
        'reason' => 'Confirmation response'
    ),
    
    // Should use OpenAI system
    array(
        'message' => 'My daughter is 6 years old and I want good education for her',
        'expected' => 'OPENAI',
        'reason' => 'Natural language query'
    ),
    array(
        'message' => 'What makes your school different from others?',
        'expected' => 'OPENAI',
        'reason' => 'Comparative question'
    ),
    array(
        'message' => 'Do you have special programs for gifted children?',
        'expected' => 'OPENAI',
        'reason' => 'Specific program inquiry'
    ),
    array(
        'message' => 'Tell me about your science facilities',
        'expected' => 'OPENAI',
        'reason' => 'Facilities inquiry'
    )
);

echo "Testing routing logic...\n\n";

try {
    // Initialize shortcode class (which contains our routing logic)
    if (class_exists('EduBot_Shortcode')) {
        $shortcode = new EduBot_Shortcode();
        
        // Use reflection to access private method
        $reflection = new ReflectionClass($shortcode);
        $method = $reflection->getMethod('is_structured_admission_data');
        $method->setAccessible(true);
        
        foreach ($test_cases as $index => $test) {
            $should_use_rule_based = $method->invoke($shortcode, $test['message'], '');
            $actual = $should_use_rule_based ? 'RULE-BASED' : 'OPENAI';
            $status = ($actual === $test['expected']) ? '✅' : '❌';
            
            echo "Test " . ($index + 1) . ": {$status}\n";
            echo "Message: \"{$test['message']}\"\n";
            echo "Expected: {$test['expected']} | Actual: {$actual}\n";
            echo "Reason: {$test['reason']}\n";
            echo "---\n";
        }
        
    } else {
        echo "❌ EduBot_Shortcode class not found\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error during testing: " . $e->getMessage() . "\n";
}

echo "\n**System Status:**\n";

// Check if OpenAI API key is configured
$api_keys = array();
if (class_exists('EduBot_School_Config')) {
    try {
        $school_config = EduBot_School_Config::getInstance();
        $api_keys = $school_config->get_api_keys();
    } catch (Exception $e) {
        echo "❌ Could not load school config: " . $e->getMessage() . "\n";
    }
}

if (!empty($api_keys['openai_key'])) {
    echo "✅ OpenAI API Key: Configured\n";
} else {
    echo "⚠️  OpenAI API Key: Not configured\n";
    echo "   -> Configure in WordPress Admin > EduBot > Settings\n";
}

if (class_exists('EduBot_API_Integrations')) {
    echo "✅ API Integrations: Available\n";
} else {
    echo "❌ API Integrations: Class not found\n";
}

echo "\n**Next Steps:**\n";
echo "1. Configure OpenAI API key in admin panel\n";
echo "2. Test with actual chatbot interface\n";
echo "3. Monitor logs for routing decisions\n";
echo "4. Adjust routing logic as needed\n\n";

echo "**Benefits of Hybrid System:**\n";
echo "✅ Efficient rule-based processing for structured admission data\n";
echo "✅ Natural conversation for general inquiries\n";
echo "✅ Graceful fallback to rule-based system if OpenAI fails\n";
echo "✅ Best user experience with minimal API costs\n";

?>
