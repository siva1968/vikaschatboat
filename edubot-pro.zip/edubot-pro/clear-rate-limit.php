<?php
/**
 * Clear Rate Limit for API Testing
 * Run this script to reset the API test rate limit for development
 */

// Set WordPress environment
define('WP_USE_THEMES', false);
require_once('../../../wp-load.php');

echo "=== EduBot Pro Rate Limit Reset ===\n\n";

if (!class_exists('EduBot_Security_Manager')) {
    echo "❌ EduBot Security Manager not available\n";
    exit;
}

$security_manager = new EduBot_Security_Manager();
$user_id = 1; // Admin user ID (adjust if needed)

// Clear rate limits for API testing
$api_test_identifier = 'api_test_' . $user_id;
$api_settings_identifier = 'api_settings';

echo "Clearing rate limits...\n";

$api_test_cleared = $security_manager->clear_rate_limit($api_test_identifier);
$api_settings_cleared = $security_manager->clear_rate_limit($api_settings_identifier);

echo "✅ API test rate limit cleared: " . ($api_test_cleared ? "Success" : "Not found") . "\n";
echo "✅ API settings rate limit cleared: " . ($api_settings_cleared ? "Success" : "Not found") . "\n";

echo "\n🚀 Rate limits reset! You can now test the API again.\n";
echo "Note: Rate limit increased to 50 requests per hour for development.\n";
?>
