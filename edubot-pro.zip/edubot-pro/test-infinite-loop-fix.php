<?php
/**
 * Test script to verify infinite loop fix for EduBot School Config
 */

// Set up WordPress environment
require_once dirname(__FILE__) . '/../../../wp-load.php';

error_log('=== EduBot Config Loop Test Started ===');

// Test 1: Basic singleton pattern
echo "<h2>Test 1: Singleton Pattern</h2>";
$config1 = EduBot_School_Config::getInstance();
$config2 = EduBot_School_Config::getInstance();

if ($config1 === $config2) {
    echo "<p style='color: green;'>✅ Singleton pattern working correctly - same instance returned</p>";
} else {
    echo "<p style='color: red;'>❌ Singleton pattern failed - different instances returned</p>";
}

// Test 2: Multiple get_config calls should use cache
echo "<h2>Test 2: Configuration Caching</h2>";
$start_time = microtime(true);
$config_data1 = $config1->get_config();
$first_call_time = microtime(true) - $start_time;

$start_time = microtime(true);
$config_data2 = $config1->get_config();
$second_call_time = microtime(true) - $start_time;

echo "<p>First call time: " . round($first_call_time * 1000, 2) . "ms</p>";
echo "<p>Second call time: " . round($second_call_time * 1000, 2) . "ms</p>";

if ($second_call_time < $first_call_time / 2) {
    echo "<p style='color: green;'>✅ Configuration caching working - second call much faster</p>";
} else {
    echo "<p style='color: orange;'>⚠️ Caching may not be working optimally</p>";
}

// Test 3: Multiple class instantiations
echo "<h2>Test 3: Multiple Class Instantiations</h2>";
try {
    $branding_manager = new EduBot_Branding_Manager();
    $api_integrations = new EduBot_API_Integrations();
    $notification_manager = new EduBot_Notification_Manager();
    
    echo "<p style='color: green;'>✅ Multiple class instantiations successful without infinite loop</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error during class instantiation: " . $e->getMessage() . "</p>";
}

// Test 4: Shortcode rendering test
echo "<h2>Test 4: Shortcode Rendering (Safe Test)</h2>";
try {
    $shortcode = new EduBot_Shortcode();
    echo "<p style='color: green;'>✅ Shortcode class instantiated successfully</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error instantiating shortcode: " . $e->getMessage() . "</p>";
}

// Clear cache and test again
echo "<h2>Test 5: Cache Clearing</h2>";
EduBot_School_Config::clear_cache();
$config_after_clear = EduBot_School_Config::getInstance()->get_config();
echo "<p style='color: green;'>✅ Cache cleared and config reloaded successfully</p>";

error_log('=== EduBot Config Loop Test Completed ===');

echo "<h2>Test Summary</h2>";
echo "<p>All tests completed. Check error logs for detailed information.</p>";
echo "<p>If you see this message, the infinite loop issue has been resolved!</p>";
?>
