<?php
/**
 * Simple test for the hybrid system routing logic
 * Tests the logic without requiring WordPress
 */

echo "🤖 **EduBot Hybrid System Routing Test**\n";
echo "=====================================\n\n";

// Simulate the routing logic
function is_structured_admission_data($message, $session_data = array()) {
    $message_lower = strtolower($message);
    
    // Always use rule-based system if we're in an active admission flow
    if (!empty($session_data) && (
        !empty($session_data['student_name']) || 
        !empty($session_data['email']) || 
        !empty($session_data['phone']) ||
        !empty($session_data['grade']) ||
        !empty($session_data['board'])
    )) {
        return true;
    }
    
    // Use rule-based for explicit admission requests
    if (preg_match('/\b(admission|apply|enroll|join)\b/i', $message_lower)) {
        return true;
    }
    
    // Use rule-based for structured personal information
    if (preg_match('/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/', $message) ||
        preg_match('/(\+?91|0)?[\s-]?[6-9]\d{9}/', $message)) {
        return true;
    }
    
    // Use rule-based for grade and board combinations
    if (preg_match('/\b(nursery|pre-?kg|lkg|ukg|grade|class|\d+th|\d+st|\d+nd|\d+rd)\b/i', $message_lower) &&
        preg_match('/\b(cbse|caie|cambridge|state|icse|igcse|international|ib|bse)\b/i', $message_lower)) {
        return true;
    }
    
    // Use rule-based for confirmation responses
    if (preg_match('/\b(confirm|yes|complete|finish)\b/i', $message_lower)) {
        return true;
    }
    
    // Use rule-based for age and address information (but not in natural conversation)
    if ((preg_match('/\b(\d{1,2})\s*(years?|yrs?)\s*old\b/i', $message_lower) && 
         str_word_count($message) <= 6) ||
        (preg_match('/\b(\d{1,2})\s*(years?|yrs?)?\b/i', $message_lower) && 
         !preg_match('/\b(daughter|son|child|kid|want|good|education|looking|seeking)\b/i', $message_lower)) ||
        preg_match('/\baddress\b/i', $message_lower)) {
        return true;
    }
    
    // Everything else goes to OpenAI for natural language processing
    return false;
}

// Test cases
$test_cases = array(
    // Should use RULE-BASED system
    array(
        'message' => 'admission',
        'session' => array(),
        'expected' => 'RULE-BASED',
        'reason' => 'Explicit admission request'
    ),
    array(
        'message' => 'Grade 1 CBSE 2025-26',
        'session' => array(),
        'expected' => 'RULE-BASED',
        'reason' => 'Structured grade + board + year'
    ),
    array(
        'message' => 'Name: John, Email: john@email.com, Phone: 9876543210',
        'session' => array(),
        'expected' => 'RULE-BASED',
        'reason' => 'Personal information with email/phone'
    ),
    array(
        'message' => 'confirm',
        'session' => array(),
        'expected' => 'RULE-BASED',
        'reason' => 'Confirmation response'
    ),
    array(
        'message' => 'LKG',
        'session' => array('student_name' => 'John'),
        'expected' => 'RULE-BASED',
        'reason' => 'Active admission session'
    ),
    array(
        'message' => '16 years old',
        'session' => array(),
        'expected' => 'RULE-BASED',
        'reason' => 'Age information'
    ),
    
    // Should use OpenAI system
    array(
        'message' => 'My daughter is 6 years old and I want good education for her',
        'session' => array(),
        'expected' => 'OPENAI',
        'reason' => 'Natural language query'
    ),
    array(
        'message' => 'What makes your school different from others?',
        'session' => array(),
        'expected' => 'OPENAI',
        'reason' => 'Comparative question'
    ),
    array(
        'message' => 'Do you have special programs for gifted children?',
        'session' => array(),
        'expected' => 'OPENAI',
        'reason' => 'Specific program inquiry'
    ),
    array(
        'message' => 'Tell me about your science facilities',
        'session' => array(),
        'expected' => 'OPENAI',
        'reason' => 'Facilities inquiry'
    ),
    array(
        'message' => 'What are your school timings?',
        'session' => array(),
        'expected' => 'OPENAI',
        'reason' => 'General information'
    ),
    array(
        'message' => 'How much do you charge for tuition?',
        'session' => array(),
        'expected' => 'OPENAI',
        'reason' => 'Cost inquiry (natural language)'
    )
);

echo "Testing routing logic...\n\n";

$passed = 0;
$total = count($test_cases);

foreach ($test_cases as $index => $test) {
    $should_use_rule_based = is_structured_admission_data($test['message'], $test['session']);
    $actual = $should_use_rule_based ? 'RULE-BASED' : 'OPENAI';
    $status = ($actual === $test['expected']) ? '✅' : '❌';
    
    if ($actual === $test['expected']) {
        $passed++;
    }
    
    echo "Test " . ($index + 1) . ": {$status}\n";
    echo "Message: \"{$test['message']}\"\n";
    echo "Expected: {$test['expected']} | Actual: {$actual}\n";
    echo "Reason: {$test['reason']}\n";
    if (!empty($test['session'])) {
        echo "Session: " . json_encode($test['session']) . "\n";
    }
    echo "---\n";
}

echo "\n**Test Results:**\n";
echo "Passed: {$passed}/{$total} tests\n";
$percentage = round(($passed / $total) * 100, 1);
echo "Success Rate: {$percentage}%\n\n";

if ($passed === $total) {
    echo "🎉 **All tests passed!** The routing logic is working correctly.\n\n";
} else {
    echo "⚠️  Some tests failed. Review the routing logic.\n\n";
}

echo "**How the Hybrid System Works:**\n\n";
echo "📋 **RULE-BASED Processing** (Fast & Efficient):\n";
echo "   • Admission enquiry flow (name, email, phone, grade, board)\n";
echo "   • Structured data collection\n";
echo "   • Confirmation responses\n";
echo "   • Age and address information\n";
echo "   • When user is already in admission flow\n\n";

echo "🤖 **OpenAI Processing** (Natural & Intelligent):\n";
echo "   • General questions about school\n";
echo "   • Comparative inquiries\n";
echo "   • Facility and program questions\n";
echo "   • Natural language conversations\n";
echo "   • Complex parent concerns\n\n";

echo "🔄 **Fallback Strategy:**\n";
echo "   • If OpenAI fails → Automatic fallback to rule-based\n";
echo "   • If no API key → Rule-based system continues working\n";
echo "   • Zero downtime, maximum reliability\n\n";

echo "💡 **Benefits:**\n";
echo "   ✅ Efficient admission process (rule-based)\n";
echo "   ✅ Natural conversations (OpenAI)\n";
echo "   ✅ Cost-effective (rules for structured data)\n";
echo "   ✅ Reliable (graceful fallbacks)\n";
echo "   ✅ Best user experience\n";

?>
