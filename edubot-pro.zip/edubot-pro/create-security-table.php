<?php
/**
 * Simple Database Table Creator for EduBot Pro
 * Creates the missing wp_edubot_security_log table
 */

echo "EduBot Pro Database Table Creator\n";
echo "=================================\n\n";

// Database configuration - modify these values to match your setup
$db_host = 'localhost';
$db_name = 'your_database_name';
$db_user = 'your_username'; 
$db_pass = 'your_password';
$table_prefix = 'wp_';

echo "Connecting to database...\n";

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully!\n\n";
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage() . "\n";
    echo "Please update the database configuration at the top of this script.\n";
    exit(1);
}

// Define the table we need to create
$table_name = $table_prefix . 'edubot_security_log';

// Check if table exists
$check_sql = "SHOW TABLES LIKE :table_name";
$stmt = $pdo->prepare($check_sql);
$stmt->execute(['table_name' => $table_name]);

if ($stmt->rowCount() > 0) {
    echo "Table '$table_name' already exists.\n";
} else {
    echo "Creating table '$table_name'...\n";
    
    $create_sql = "CREATE TABLE `$table_name` (
        `id` bigint(20) NOT NULL AUTO_INCREMENT,
        `site_id` bigint(20) NOT NULL,
        `event_type` varchar(100) NOT NULL,
        `ip_address` varchar(45) NOT NULL,
        `user_agent` text,
        `details` longtext,
        `severity` varchar(20) DEFAULT 'medium',
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `site_id` (`site_id`),
        KEY `event_type` (`event_type`),
        KEY `ip_address` (`ip_address`),
        KEY `created_at` (`created_at`),
        KEY `severity` (`severity`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    try {
        $pdo->exec($create_sql);
        echo "Table '$table_name' created successfully!\n";
    } catch(PDOException $e) {
        echo "Error creating table: " . $e->getMessage() . "\n";
        exit(1);
    }
}

// Check if we need other tables too
$required_tables = [
    'edubot_visitor_analytics',
    'edubot_visitors', 
    'edubot_applications',
    'edubot_analytics',
    'edubot_sessions',
    'edubot_school_configs'
];

echo "\nChecking other required tables...\n";

foreach ($required_tables as $table) {
    $full_name = $table_prefix . $table;
    $stmt = $pdo->prepare($check_sql);
    $stmt->execute(['table_name' => $full_name]);
    
    if ($stmt->rowCount() > 0) {
        echo "✓ $full_name exists\n";
    } else {
        echo "✗ $full_name MISSING\n";
    }
}

echo "\nDatabase check completed!\n";
echo "If any tables are missing, please run the full WordPress plugin activation.\n";
?>
