<?php
/**
 * Network Connectivity Test for ZeptoMail SMTP
 */

echo "=== ZeptoMail SMTP Network Connectivity Test ===\n\n";

$host = 'smtp.zeptomail.in';
$ports = array(587, 25, 2525, 465);

echo "Testing connectivity to {$host}...\n\n";

// Test DNS resolution
echo "1. DNS Resolution Test:\n";
$ip = gethostbyname($host);
if ($ip === $host) {
    echo "   ❌ DNS resolution failed for {$host}\n";
} else {
    echo "   ✅ DNS resolved {$host} to {$ip}\n";
}

// Test connectivity on different ports
echo "\n2. Port Connectivity Tests:\n";
foreach ($ports as $port) {
    echo "   Testing port {$port}... ";
    
    $start_time = microtime(true);
    $connection = @fsockopen($host, $port, $errno, $errstr, 15);
    $end_time = microtime(true);
    $duration = round(($end_time - $start_time) * 1000, 2);
    
    if ($connection) {
        fclose($connection);
        echo "✅ Connected in {$duration}ms\n";
    } else {
        echo "❌ Failed - {$errstr} ({$errno}) - {$duration}ms\n";
    }
}

// Test alternative SMTP hosts
echo "\n3. Alternative SMTP Server Tests:\n";
$alt_hosts = array(
    'smtp.gmail.com' => 587,
    'smtp.mailgun.org' => 587,
    'smtp.sendgrid.net' => 587
);

foreach ($alt_hosts as $alt_host => $alt_port) {
    echo "   Testing {$alt_host}:{$alt_port}... ";
    
    $connection = @fsockopen($alt_host, $alt_port, $errno, $errstr, 10);
    if ($connection) {
        fclose($connection);
        echo "✅ Connected\n";
    } else {
        echo "❌ Failed - {$errstr}\n";
    }
}

// Check server environment
echo "\n4. Server Environment:\n";
echo "   PHP Version: " . phpversion() . "\n";
echo "   OpenSSL: " . (extension_loaded('openssl') ? '✅ Enabled' : '❌ Disabled') . "\n";
echo "   Socket functions: " . (function_exists('fsockopen') ? '✅ Available' : '❌ Disabled') . "\n";
echo "   Allow URL fopen: " . (ini_get('allow_url_fopen') ? '✅ Enabled' : '❌ Disabled') . "\n";

// Recommendations
echo "\n=== Diagnosis & Recommendations ===\n";
echo "If ZeptoMail ports are blocked but other SMTP servers work:\n";
echo "• Contact your hosting provider about outbound SMTP restrictions\n";
echo "• Request unblocking of smtp.zeptomail.in on ports 587, 25, 2525, 465\n";
echo "• Consider using ZeptoMail API instead of SMTP\n";
echo "• Test from a different server/network environment\n";

echo "\nIf all SMTP servers are blocked:\n";
echo "• Your server has strict firewall rules blocking outbound SMTP\n";
echo "• Contact hosting provider to allow outbound SMTP connections\n";
echo "• Use API-based email services instead of SMTP\n";

echo "\n🔍 Run this test from your server to diagnose the network issue!\n";
?>
