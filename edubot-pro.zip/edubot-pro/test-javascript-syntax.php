<?php
/**
 * Test Academic Config JavaScript Syntax
 * This script extracts and validates the JavaScript from the academic config template
 */

echo "=== Academic Config JavaScript Syntax Test ===\n\n";

// Read the academic config file
$file_path = __DIR__ . '/admin/partials/academic-config.php';
if (!file_exists($file_path)) {
    echo "❌ File not found: $file_path\n";
    exit(1);
}

$content = file_get_contents($file_path);

// Extract JavaScript section
$start_marker = '<script>';
$end_marker = '</script>';

$start_pos = strpos($content, $start_marker);
$end_pos = strpos($content, $end_marker);

if ($start_pos === false || $end_pos === false) {
    echo "❌ JavaScript section not found\n";
    exit(1);
}

$js_content = substr($content, $start_pos + strlen($start_marker), $end_pos - $start_pos - strlen($start_marker));

echo "✅ JavaScript section extracted successfully\n\n";

// Check for common syntax issues
$issues = array();

// Check for PHP code in JavaScript
if (preg_match('/\<\?php/', $js_content)) {
    $issues[] = "PHP code found in JavaScript section";
}

// Check for unescaped quotes in template strings
if (preg_match('/`[^`]*[\'"][^`]*`/', $js_content)) {
    // More specific check for unescaped quotes
    preg_match_all('/`([^`]*)`/', $js_content, $templates);
    foreach ($templates[1] as $template) {
        if (preg_match('/(?<!\\\\)[\'"]/', $template)) {
            $issues[] = "Unescaped quotes found in template string";
            break;
        }
    }
}

// Check for missing semicolons at critical points
$lines = explode("\n", $js_content);
foreach ($lines as $line_num => $line) {
    $line = trim($line);
    if (preg_match('/^\s*(var|let|const|function|\}|\);)/', $line) && !preg_match('/[;,\{]$/', $line) && $line !== '') {
        // Skip lines that are part of object/function definitions
        if (!preg_match('/[\{\(]$/', $line)) {
            $issues[] = "Possible missing semicolon at line " . ($line_num + 1) . ": " . substr($line, 0, 50);
        }
    }
}

// Check parentheses balance
$open_parens = substr_count($js_content, '(');
$close_parens = substr_count($js_content, ')');
if ($open_parens !== $close_parens) {
    $issues[] = "Unbalanced parentheses: $open_parens opening, $close_parens closing";
}

// Check curly braces balance
$open_braces = substr_count($js_content, '{');
$close_braces = substr_count($js_content, '}');
if ($open_braces !== $close_braces) {
    $issues[] = "Unbalanced curly braces: $open_braces opening, $close_braces closing";
}

// Check template literal balance
$template_literals = substr_count($js_content, '`');
if ($template_literals % 2 !== 0) {
    $issues[] = "Unbalanced template literals (backticks)";
}

// Report results
if (empty($issues)) {
    echo "✅ JavaScript syntax validation PASSED\n";
    echo "   - No PHP code in JavaScript ✓\n";
    echo "   - Balanced parentheses ✓\n";
    echo "   - Balanced curly braces ✓\n";
    echo "   - Balanced template literals ✓\n";
    echo "   - No obvious syntax errors ✓\n";
} else {
    echo "❌ JavaScript syntax validation FAILED\n";
    foreach ($issues as $issue) {
        echo "   - $issue\n";
    }
}

echo "\n=== JavaScript Content Preview ===\n";
echo substr($js_content, 0, 500) . "...\n";

// Additional check: Look for the specific problem areas
echo "\n=== Checking Template Strings ===\n";
preg_match_all('/`([^`]*)`/s', $js_content, $matches, PREG_SET_ORDER);
foreach ($matches as $i => $match) {
    $template = trim($match[1]);
    echo "Template " . ($i + 1) . ":\n";
    echo "   " . substr(str_replace("\n", "\\n", $template), 0, 100) . "\n";
    
    // Check for PHP in this template
    if (strpos($template, '<?php') !== false) {
        echo "   ❌ Contains PHP code\n";
    } else {
        echo "   ✅ Clean JavaScript\n";
    }
}

echo "\n✅ Academic Config JavaScript Test Complete!\n";
?>
