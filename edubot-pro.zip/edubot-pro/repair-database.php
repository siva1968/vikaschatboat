<?php
/**
 * EduBot Pro Database Repair Script
 * Run this# Define required tables
$required_tables = array(
    'edubot_visitor_analytics',
    'edubot_visitors',
    'edubot_applications',
    'edubot_analytics',
    'edubot_sessions',
    'edubot_security_log',
    'edubot_school_configs'
); create missing database tables
 */

// Prevent direct access from web
if (php_sapi_name() !== 'cli') {
    die('This script can only be run from command line');
}

echo "EduBot Pro Database Repair Script\n";
echo "=================================\n\n";

// Check if WordPress is available
if (!defined('ABSPATH')) {
    // Try to find WordPress config
    $wp_config_paths = array(
        dirname(__FILE__) . '/../../../../wp-config.php',
        dirname(__FILE__) . '/../../../wp-config.php',
        dirname(__FILE__) . '/../../wp-config.php',
        dirname(__FILE__) . '/../wp-config.php'
    );
    
    $wp_found = false;
    foreach ($wp_config_paths as $path) {
        if (file_exists($path)) {
            echo "Found WordPress config at: $path\n";
            require_once $path;
            $wp_found = true;
            break;
        }
    }
    
    if (!$wp_found) {
        echo "Error: WordPress config not found. Please run this script from within a WordPress installation.\n";
        exit(1);
    }
}

// Set up minimal WordPress environment
if (!defined('WP_USE_THEMES')) {
    define('WP_USE_THEMES', false);
}

if (!isset($wpdb)) {
    global $wpdb;
    require_once ABSPATH . '/wp-includes/wp-db.php';
    require_once ABSPATH . '/wp-admin/includes/upgrade.php';
    
    $wpdb = new wpdb(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
}

// Include our database manager
require_once dirname(__FILE__) . '/includes/class-database-manager.php';

echo "Checking database tables...\n";

// Get database manager
$db_manager = new EduBot_Database_Manager();

// Define required tables
$required_tables = array(
    'edubot_visitor_analytics',
    'edubot_visitors',
    'edubot_applications',
    'edubot_analytics',
    'edubot_sessions',
    'edubot_security_logs',
    'edubot_school_configs'
);

$missing_tables = array();
$charset_collate = $wpdb->get_charset_collate();

echo "Checking for missing tables...\n";

foreach ($required_tables as $table_name) {
    $full_table_name = $wpdb->prefix . $table_name;
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$full_table_name'");
    
    if ($table_exists != $full_table_name) {
        $missing_tables[] = $table_name;
        echo "- Missing: $full_table_name\n";
    } else {
        echo "- Found: $full_table_name\n";
    }
}

if (empty($missing_tables)) {
    echo "\nAll required tables exist. No repair needed.\n";
    exit(0);
}

echo "\nFound " . count($missing_tables) . " missing tables.\n";
echo "Creating missing tables...\n";

// Create missing tables
foreach ($missing_tables as $table_name) {
    echo "Creating $table_name... ";
    
    $sql = '';
    $table = $wpdb->prefix . $table_name;
    
    switch ($table_name) {
        case 'edubot_visitor_analytics':
            $sql = "CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                site_id bigint(20) NOT NULL,
                visitor_id varchar(255) NOT NULL,
                session_id varchar(255) NOT NULL,
                page_url text NOT NULL,
                referrer_url text,
                user_agent text,
                ip_address varchar(45),
                country varchar(100),
                city varchar(100),
                device_type varchar(50),
                browser varchar(50),
                os varchar(50),
                screen_resolution varchar(20),
                time_on_page int(11) DEFAULT 0,
                interactions_count int(11) DEFAULT 0,
                conversion_event varchar(100),
                utm_source varchar(100),
                utm_medium varchar(100),
                utm_campaign varchar(100),
                timestamp datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY site_id (site_id),
                KEY visitor_id (visitor_id),
                KEY session_id (session_id),
                KEY timestamp (timestamp),
                KEY conversion_event (conversion_event)
            ) $charset_collate;";
            break;
            
        case 'edubot_visitors':
            $sql = "CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                site_id bigint(20) NOT NULL,
                visitor_id varchar(255) NOT NULL,
                email varchar(255),
                phone varchar(20),
                name varchar(255),
                first_visit datetime DEFAULT CURRENT_TIMESTAMP,
                last_activity datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                total_visits int(11) DEFAULT 1,
                total_time_spent int(11) DEFAULT 0,
                pages_visited int(11) DEFAULT 0,
                interactions_count int(11) DEFAULT 0,
                lead_score int(11) DEFAULT 0,
                status varchar(50) DEFAULT 'anonymous',
                is_returning tinyint(1) DEFAULT 0,
                marketing_source varchar(100),
                conversion_status varchar(50) DEFAULT 'none',
                notes longtext,
                custom_data longtext,
                PRIMARY KEY (id),
                UNIQUE KEY visitor_id (visitor_id, site_id),
                KEY site_id (site_id),
                KEY email (email),
                KEY status (status),
                KEY is_returning (is_returning),
                KEY last_activity (last_activity),
                KEY marketing_source (marketing_source)
            ) $charset_collate;";
            break;
            
        case 'edubot_applications':
            $sql = "CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                site_id bigint(20) NOT NULL,
                application_number varchar(50) NOT NULL,
                student_data longtext NOT NULL,
                custom_fields_data longtext,
                conversation_log longtext,
                status varchar(50) DEFAULT 'pending',
                source varchar(50) DEFAULT 'chatbot',
                ip_address varchar(45),
                user_agent text,
                utm_data longtext,
                whatsapp_sent tinyint(1) DEFAULT 0,
                email_sent tinyint(1) DEFAULT 0,
                sms_sent tinyint(1) DEFAULT 0,
                follow_up_scheduled datetime,
                assigned_to bigint(20),
                priority varchar(20) DEFAULT 'normal',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY application_number (application_number),
                KEY site_id (site_id),
                KEY status (status),
                KEY created_at (created_at)
            ) $charset_collate;";
            break;
            
        case 'edubot_analytics':
            $sql = "CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                site_id bigint(20) NOT NULL,
                session_id varchar(255) NOT NULL,
                event_type varchar(50) NOT NULL,
                event_data longtext,
                ip_address varchar(45),
                user_agent text,
                timestamp datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY site_id (site_id),
                KEY session_id (session_id),
                KEY event_type (event_type),
                KEY timestamp (timestamp)
            ) $charset_collate;";
            break;
            
        case 'edubot_sessions':
            $sql = "CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                site_id bigint(20) NOT NULL,
                session_id varchar(255) NOT NULL,
                user_data longtext,
                conversation_state longtext,
                current_step varchar(100),
                started_at datetime DEFAULT CURRENT_TIMESTAMP,
                last_activity datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                completed_at datetime,
                status varchar(50) DEFAULT 'active',
                ip_address varchar(45),
                user_agent text,
                PRIMARY KEY (id),
                UNIQUE KEY session_id (session_id),
                KEY site_id (site_id),
                KEY status (status),
                KEY last_activity (last_activity)
            ) $charset_collate;";
            break;
            
        case 'edubot_security_log':
            $sql = "CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                site_id bigint(20) NOT NULL,
                event_type varchar(100) NOT NULL,
                ip_address varchar(45) NOT NULL,
                user_agent text,
                details longtext,
                severity varchar(20) DEFAULT 'medium',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY site_id (site_id),
                KEY event_type (event_type),
                KEY ip_address (ip_address),
                KEY created_at (created_at),
                KEY severity (severity)
            ) $charset_collate;";
            break;
            
        case 'edubot_school_configs':
            $sql = "CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                site_id bigint(20) NOT NULL,
                school_name varchar(255) NOT NULL,
                config_data longtext NOT NULL,
                api_keys_encrypted longtext,
                branding_settings longtext,
                academic_structure longtext,
                board_settings longtext,
                academic_year_settings longtext,
                status varchar(20) DEFAULT 'active',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY site_id (site_id)
            ) $charset_collate;";
            break;
    }
    
    if ($sql) {
        $result = dbDelta($sql);
        if (!empty($result)) {
            echo "SUCCESS\n";
        } else {
            echo "FAILED\n";
        }
    } else {
        echo "NO SQL DEFINED\n";
    }
}

echo "\nDatabase repair completed!\n";
echo "Please check your WordPress site to verify the tables were created successfully.\n";
