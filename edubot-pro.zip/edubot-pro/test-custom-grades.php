<?php
/**
 * Test form processing for custom grades
 */

echo "=== Testing Custom Grades Form Processing ===\n\n";

// Simulate form data
$_POST['academic_config'] = array(
    'grade_systems' => array('elementary', 'middle'),
    'custom_grades_keys' => array('foundation', 'preparatory', 'advanced'),
    'custom_grades_labels' => array('Foundation Level', 'Preparatory Class', 'Advanced Studies')
);

echo "1. Simulated form data:\n";
print_r($_POST['academic_config']);

echo "\n2. Processing custom grades...\n";

$config_data = $_POST['academic_config'];
$custom_grades = array();

if (isset($config_data['custom_grades_keys']) && isset($config_data['custom_grades_labels'])) {
    $keys = $config_data['custom_grades_keys'];
    $labels = $config_data['custom_grades_labels'];
    
    echo "Keys: " . print_r($keys, true);
    echo "Labels: " . print_r($labels, true);
    
    if (is_array($keys) && is_array($labels)) {
        for ($i = 0; $i < count($keys) && $i < count($labels); $i++) {
            $key = sanitize_key($keys[$i]);
            $label = sanitize_text_field($labels[$i]);
            
            echo "Processing: key='$key', label='$label'\n";
            
            if (!empty($key) && !empty($label) && strlen($label) <= 50) {
                $custom_grades[$key] = $label;
                echo "✅ Added: $key => $label\n";
            } else {
                echo "❌ Skipped: key='$key', label='$label' (validation failed)\n";
            }
        }
    }
}

echo "\n3. Final custom grades array:\n";
print_r($custom_grades);

echo "\n4. Checking form field names...\n";
echo "Form sends: academic_config[custom_grades_keys][]\n";
echo "Form sends: academic_config[custom_grades_labels][]\n";
echo "Save method looks for: academic_config['custom_grades_keys']\n";
echo "Save method looks for: academic_config['custom_grades_labels']\n";
echo "✅ Field names match!\n";

echo "\n=== Test Complete ===\n";

// Helper functions (simplified versions)
function sanitize_key($key) {
    return preg_replace('/[^a-z0-9_\-]/', '', strtolower($key));
}

function sanitize_text_field($str) {
    return trim(strip_tags($str));
}
?>
