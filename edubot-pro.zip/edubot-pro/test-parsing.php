<?php
/**
 * Test comprehensive admission info parsing
 */

echo "🧪 **Testing Comprehensive Admission Info Parsing**\n";
echo "==============================================\n\n";

// Test parsing function logic
function parse_comprehensive_admission_info($message) {
    $extracted_data = array();
    $message_lower = strtolower($message);
    
    // Extract student name from patterns - handle specific cases first
    $student_name = '';
    
    // Pattern 1: "for my son/daughter/child NAME for/in CLASS" (handle typos like "sun")
    if (preg_match('/for my (?:son|sun|daughter|child)\s+([a-zA-Z]+)\s+for/i', $message, $matches)) {
        $student_name = ucfirst(trim($matches[1]));
    }
    // Pattern 2: "my son/daughter/child NAME needs/wants"
    elseif (preg_match('/my (?:son|sun|daughter|child)\s+([a-zA-Z]+)\s+(?:needs|wants|requires)/i', $message, $matches)) {
        $student_name = ucfirst(trim($matches[1]));
    }
    // Pattern 3: "my daughter/son NAME"
    elseif (preg_match('/my (?:son|sun|daughter|child)\s+([a-zA-Z]+)/i', $message, $matches)) {
        $student_name = ucfirst(trim($matches[1]));
    }
    // Pattern 4: "child named NAME"
    elseif (preg_match('/child named\s+([a-zA-Z]+)/i', $message, $matches)) {
        $student_name = ucfirst(trim($matches[1]));
    }
    // Pattern 5: "admission for NAME" (but not "admission for my")
    elseif (preg_match('/admission for\s+([a-zA-Z]+)(?:\s|$)/i', $message, $matches)) {
        $potential_name = ucfirst(trim($matches[1]));
        if (!in_array(strtolower($potential_name), array('my', 'his', 'her', 'the', 'a', 'an'))) {
            $student_name = $potential_name;
        }
    }
    
    if (!empty($student_name) && strlen($student_name) >= 2 && strlen($student_name) <= 20) {
        $extracted_data['student_name'] = $student_name;
    }
    
    // Extract grade/class information (handle typos like "nursary")
    $grade_patterns = array(
        '/\b(nursery|nursary|pre-?kg|lkg|ukg)\b/i',
        '/\b(?:grade|class)\s*(\d+)\b/i',
        '/\b(\d+)(?:st|nd|rd|th)\s*(?:grade|class)?\b/i'
    );
    
    foreach ($grade_patterns as $pattern) {
        if (preg_match($pattern, $message, $matches)) {
            $grade = ucfirst(strtolower($matches[0]));
            // Normalize grade names (handle typos)
            if (stripos($grade, 'nursery') !== false || stripos($grade, 'nursary') !== false) $grade = 'Nursery';
            elseif (stripos($grade, 'pre') !== false) $grade = 'Pre-KG';
            elseif (stripos($grade, 'lkg') !== false) $grade = 'LKG';
            elseif (stripos($grade, 'ukg') !== false) $grade = 'UKG';
            elseif (preg_match('/(\d+)/', $grade, $num_match)) {
                $grade = 'Grade ' . $num_match[1];
            }
            $extracted_data['grade'] = $grade;
            break;
        }
    }
    
    // Extract academic year
    if (preg_match('/\b(20\d{2}[-\/]?\d{2})\b/', $message, $year_matches)) {
        $year = $year_matches[1];
        // Normalize year format
        if (strpos($year, '-') === false && strpos($year, '/') === false) {
            // Convert 202525 to 2025-25
            if (strlen($year) == 6) {
                $year = substr($year, 0, 4) . '-' . substr($year, 4, 2);
            }
        }
        $extracted_data['academic_year'] = $year;
    }
    
    return $extracted_data;
}

// Test cases
$test_cases = array(
    "I am looking for admission for my sun Sujay for Nursary for the accodamic year 2025-25",
    "My daughter Priya needs admission in Grade 1",
    "admission for my son Alex in LKG for 2025-26",
    "I want to enroll my child named Sarah in UKG",
    "Looking for Grade 5 admission for my daughter",
    "My son needs admission in 3rd grade for academic year 2025-26"
);

foreach ($test_cases as $index => $test_message) {
    echo "Test " . ($index + 1) . ":\n";
    echo "Input: \"$test_message\"\n";
    
    $result = parse_comprehensive_admission_info($test_message);
    
    if (!empty($result)) {
        echo "Extracted:\n";
        foreach ($result as $key => $value) {
            echo "  • $key: $value\n";
        }
    } else {
        echo "  No information extracted\n";
    }
    echo "---\n";
}

echo "\n✅ **Key Test Case (Your Example):**\n";
$your_message = "I am looking for admission for my sun Sujay for Nursary for the accodamic year 2025-25";
$result = parse_comprehensive_admission_info($your_message);

echo "Input: \"$your_message\"\n";
echo "Expected to extract:\n";
echo "  • Student Name: Sujay\n";
echo "  • Grade: Nursery\n";
echo "  • Academic Year: 2025-25\n\n";

echo "Actually extracted:\n";
if (!empty($result)) {
    foreach ($result as $key => $value) {
        echo "  • $key: $value\n";
    }
} else {
    echo "  ❌ No information extracted\n";
}

?>
