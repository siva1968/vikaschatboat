<?php
/**
 * Quick test script for EduBot Pro Security Manager URL validation
 * Place this in your WordPress root directory and access via browser to test
 */

// Load WordPress
require_once dirname(__FILE__) . '/wp-config.php';
require_once dirname(__FILE__) . '/wp-load.php';

echo "<h2>EduBot Pro Security Manager Test</h2>";

// Test if Security Manager class exists
if (!class_exists('EduBot_Security_Manager')) {
    // Try to load it manually
    $security_manager_path = dirname(__FILE__) . '/wp-content/plugins/edubot-pro/includes/class-security-manager.php';
    if (file_exists($security_manager_path)) {
        require_once $security_manager_path;
        echo "<p style='color: orange;'>Loaded Security Manager manually</p>";
    } else {
        echo "<p style='color: red;'>Security Manager class file not found at: $security_manager_path</p>";
        exit;
    }
}

if (class_exists('EduBot_Security_Manager')) {
    echo "<p style='color: green;'>✓ Security Manager class found</p>";
    
    $security_manager = new EduBot_Security_Manager();
    
    // Test if is_safe_url method exists
    if (method_exists($security_manager, 'is_safe_url')) {
        echo "<p style='color: green;'>✓ is_safe_url method exists</p>";
        
        // Test various URLs
        $test_urls = array(
            'https://example.com/logo.png' => 'Should be safe',
            'http://example.com/image.jpg' => 'Should be safe', 
            'javascript:alert("xss")' => 'Should be unsafe',
            'data:image/png;base64,abc' => 'Should be unsafe',
            '' => 'Should be unsafe (empty)',
            'not-a-url' => 'Should be unsafe (invalid format)'
        );
        
        echo "<h3>URL Validation Tests:</h3>";
        foreach ($test_urls as $url => $description) {
            try {
                $result = $security_manager->is_safe_url($url);
                $status = $result ? 'SAFE' : 'UNSAFE';
                $color = ($url === '' || strpos($url, 'javascript') !== false || strpos($url, 'data:') !== false || $url === 'not-a-url') 
                    ? ($result ? 'red' : 'green') 
                    : ($result ? 'green' : 'red');
                
                echo "<p><strong>URL:</strong> '$url'<br>";
                echo "<strong>Expected:</strong> $description<br>";
                echo "<strong>Result:</strong> <span style='color: $color;'>$status</span></p>";
                
            } catch (Exception $e) {
                echo "<p style='color: red;'><strong>Error testing URL '$url':</strong> " . $e->getMessage() . "</p>";
            }
        }
        
    } else {
        echo "<p style='color: red;'>✗ is_safe_url method NOT found in Security Manager</p>";
        
        // List available methods
        $methods = get_class_methods($security_manager);
        echo "<p><strong>Available methods:</strong> " . implode(', ', $methods) . "</p>";
    }
    
} else {
    echo "<p style='color: red;'>✗ Security Manager class not found</p>";
}

echo "<h3>WordPress Environment Info:</h3>";
echo "<p><strong>WordPress Version:</strong> " . get_bloginfo('version') . "</p>";
echo "<p><strong>Plugin Active:</strong> " . (is_plugin_active('edubot-pro/edubot-pro.php') ? 'Yes' : 'No') . "</p>";
echo "<p><strong>Current User Can Manage Options:</strong> " . (current_user_can('manage_options') ? 'Yes' : 'No') . "</p>";
echo "<p><strong>PHP Version:</strong> " . PHP_VERSION . "</p>";

echo "<hr>";
echo "<p><em>Test completed. Check the results above to verify the Security Manager is working correctly.</em></p>";
?>
