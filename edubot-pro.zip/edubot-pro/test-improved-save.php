<?php
/**
 * Improved School Settings Save Function
 * This is a standalone version for testing
 */

function improved_save_school_settings($post_data) {
    global $wpdb;
    
    // Input validation
    if (empty($post_data['edubot_school_name'])) {
        return array('success' => false, 'message' => 'School name is required');
    }
    
    $school_name = sanitize_text_field($post_data['edubot_school_name']);
    
    // Enhanced update_option wrapper that handles WordPress behavior correctly
    function safe_update_option($option_name, $new_value) {
        $current_value = get_option($option_name, '__NOT_SET__');
        
        // If values are the same, don't update (avoid false negative)
        if ($current_value === $new_value) {
            error_log("EduBot: Option '$option_name' unchanged, skipping update");
            return true; // Not an error
        }
        
        // Attempt update
        $result = update_option($option_name, $new_value);
        
        if ($result === false) {
            // Check if it actually failed or if WordPress just returned false
            $check_value = get_option($option_name);
            if ($check_value === $new_value) {
                error_log("EduBot: Option '$option_name' was actually updated despite false return");
                return true;
            } else {
                global $wpdb;
                error_log("EduBot: Failed to update '$option_name'. Error: " . $wpdb->last_error);
                return false;
            }
        }
        
        error_log("EduBot: Successfully updated '$option_name' to: '$new_value'");
        return true;
    }
    
    // Test the function
    echo "<h3>Testing Improved Save Function</h3>";
    
    $test_result = safe_update_option('edubot_school_name', $school_name);
    
    if ($test_result) {
        echo "<p style='color: green;'>✓ School name saved successfully: '$school_name'</p>";
        return array('success' => true, 'message' => 'Settings saved successfully');
    } else {
        echo "<p style='color: red;'>✗ Failed to save school name</p>";
        return array('success' => false, 'message' => 'Failed to save school name');
    }
}

// If this file is accessed directly, run a test
if (basename(__FILE__) === basename($_SERVER['SCRIPT_NAME'])) {
    // Load WordPress
    require_once dirname(__FILE__) . '/wp-config.php';
    require_once dirname(__FILE__) . '/wp-load.php';
    
    echo "<h2>Improved School Settings Save Test</h2>";
    
    // Simulate POST data
    $test_data = array(
        'edubot_school_name' => 'Test School Name ' . date('Y-m-d H:i:s')
    );
    
    echo "<p><strong>Current school name:</strong> '" . get_option('edubot_school_name', 'NOT_SET') . "'</p>";
    echo "<p><strong>Test school name:</strong> '" . $test_data['edubot_school_name'] . "'</p>";
    
    $result = improved_save_school_settings($test_data);
    
    echo "<p><strong>Result:</strong> " . ($result['success'] ? 'SUCCESS' : 'FAILED') . "</p>";
    echo "<p><strong>Message:</strong> " . $result['message'] . "</p>";
    
    echo "<p><strong>Final school name:</strong> '" . get_option('edubot_school_name') . "'</p>";
}
?>
