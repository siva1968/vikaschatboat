<?php
/**
 * Test Academic Config Class Loading
 */

// Simulate WordPress environment
if (!defined('ABSPATH')) {
    define('ABSPATH', '/home/epistemo-stage/htdocs/stage.epistemo.in/');
}

// Define plugin constants
define('EDUBOT_PRO_PLUGIN_PATH', __DIR__ . '/');
define('EDUBOT_PRO_PLUGIN_URL', 'http://test.local/');

echo "=== Academic Config Class Loading Test ===\n\n";

// Test 1: Direct include
echo "1. Testing direct include of class file...\n";
if (file_exists(EDUBOT_PRO_PLUGIN_PATH . 'includes/class-edubot-academic-config.php')) {
    require_once EDUBOT_PRO_PLUGIN_PATH . 'includes/class-edubot-academic-config.php';
    echo "   ✅ Class file included successfully\n";
} else {
    echo "   ❌ Class file not found\n";
    exit(1);
}

// Test 2: Check if class exists
echo "\n2. Testing class existence...\n";
if (class_exists('Edubot_Academic_Config')) {
    echo "   ✅ Edubot_Academic_Config class exists\n";
} else {
    echo "   ❌ Edubot_Academic_Config class not found\n";
}

// Test 3: Check autoloader
echo "\n3. Testing autoloader...\n";
if (file_exists(EDUBOT_PRO_PLUGIN_PATH . 'includes/class-edubot-autoloader.php')) {
    require_once EDUBOT_PRO_PLUGIN_PATH . 'includes/class-edubot-autoloader.php';
    EduBot_Autoloader::register();
    echo "   ✅ Autoloader registered\n";
} else {
    echo "   ❌ Autoloader file not found\n";
}

// Test 4: Test class methods
echo "\n4. Testing class methods...\n";
try {
    $grade_systems = Edubot_Academic_Config::get_grade_systems();
    echo "   ✅ get_grade_systems() method works\n";
    echo "   📋 Found " . count($grade_systems) . " grade systems\n";
} catch (Exception $e) {
    echo "   ❌ Error calling get_grade_systems(): " . $e->getMessage() . "\n";
}

try {
    $educational_boards = Edubot_Academic_Config::get_educational_boards();
    echo "   ✅ get_educational_boards() method works\n";
    echo "   📋 Found " . count($educational_boards) . " educational boards\n";
} catch (Exception $e) {
    echo "   ❌ Error calling get_educational_boards(): " . $e->getMessage() . "\n";
}

try {
    $academic_year_configs = Edubot_Academic_Config::get_academic_year_configs();
    echo "   ✅ get_academic_year_configs() method works\n";
    echo "   📋 Found " . count($academic_year_configs) . " academic year configs\n";
} catch (Exception $e) {
    echo "   ❌ Error calling get_academic_year_configs(): " . $e->getMessage() . "\n";
}

// Test 5: Check what the template file needs
echo "\n5. Testing template requirements...\n";
$school_id = 1; // Test with school ID 1

try {
    $academic_config = Edubot_Academic_Config::get_school_academic_config($school_id);
    echo "   ✅ get_school_academic_config() method works\n";
} catch (Exception $e) {
    echo "   ❌ Error calling get_school_academic_config(): " . $e->getMessage() . "\n";
}

try {
    $board_config = Edubot_Academic_Config::get_school_board_config($school_id);
    echo "   ✅ get_school_board_config() method works\n";
} catch (Exception $e) {
    echo "   ❌ Error calling get_school_board_config(): " . $e->getMessage() . "\n";
}

try {
    $academic_year_config = Edubot_Academic_Config::get_school_academic_year_config($school_id);
    echo "   ✅ get_school_academic_year_config() method works\n";
} catch (Exception $e) {
    echo "   ❌ Error calling get_school_academic_year_config(): " . $e->getMessage() . "\n";
}

echo "\n✅ Academic Config Class Test Complete!\n";
echo "The class should now load properly in WordPress admin.\n";
?>
