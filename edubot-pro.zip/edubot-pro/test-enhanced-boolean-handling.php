<?php
/**
 * Test script to validate enhanced boolean option handling
 * Run this script to verify the safe_update_option fixes work correctly
 */

// Simulate WordPress environment for testing
if (!function_exists('get_option')) {
    function get_option($option_name, $default = false) {
        // Simulate WordPress option storage
        $test_options = array(
            'test_bool_true' => '1',           // WordPress stores boolean true as '1'
            'test_bool_false' => '0',          // WordPress stores boolean false as '0'
            'test_string_number' => '4',       // String number
            'test_int_number' => 4,            // Integer number
            'test_string' => 'hello',          // Regular string
            'test_array' => array('a', 'b'),   // Array
        );
        
        return isset($test_options[$option_name]) ? $test_options[$option_name] : $default;
    }
}

if (!function_exists('update_option')) {
    function update_option($option_name, $value) {
        // Simulate WordPress update_option behavior
        return true; // Always return true for this test
    }
}

if (!function_exists('error_log')) {
    function error_log($message) {
        echo $message . "\n";
    }
}

// Simulate the enhanced safe_update_option method
function safe_update_option($option_name, $new_value) {
    $current_value = get_option($option_name, '__EDUBOT_NOT_SET__');
    
    // Handle boolean comparison properly
    $values_equal = false;
    if (is_bool($new_value) && is_bool($current_value)) {
        $values_equal = ($current_value === $new_value);
    } elseif (is_bool($new_value)) {
        // Current value might be stored as string '1' or '0'
        $values_equal = (($new_value === true && ($current_value === '1' || $current_value === 1 || $current_value === true)) || 
                       ($new_value === false && ($current_value === '0' || $current_value === 0 || $current_value === false)));
    } else {
        // For non-boolean values, include type-flexible comparison
        if (is_numeric($new_value) && is_numeric($current_value)) {
            $values_equal = ((string)$current_value === (string)$new_value);
        } else {
            $values_equal = ($current_value === $new_value);
        }
    }
    
    // If values are the same, don't update (avoid false negative)
    if ($values_equal) {
        error_log("✅ Option '$option_name' unchanged, skipping update");
        return true; // Not an error
    }
    
    // Attempt update
    $result = update_option($option_name, $new_value);
    
    if ($result === false) {
        error_log("❌ Failed to update '$option_name'");
        return false;
    }
    
    error_log("✅ Successfully updated '$option_name'");
    return true;
}

echo "🧪 Testing Enhanced Boolean Option Handling\n";
echo "==========================================\n\n";

// Test cases that were failing in production
$test_cases = array(
    // Boolean true vs stored '1' (should be equal)
    array('test_bool_true', true, 'Boolean true vs stored \'1\''),
    
    // Boolean false vs stored '0' (should be equal)  
    array('test_bool_false', false, 'Boolean false vs stored \'0\''),
    
    // String number vs string number (should be equal)
    array('test_string_number', '4', 'String \'4\' vs stored \'4\''),
    
    // Integer vs stored string number (should be equal)
    array('test_string_number', 4, 'Integer 4 vs stored \'4\''),
    
    // Different values (should update)
    array('test_string', 'world', 'String change: \'hello\' to \'world\''),
    
    // Array comparison
    array('test_array', array('a', 'b'), 'Array comparison (same values)'),
    array('test_array', array('x', 'y'), 'Array comparison (different values)'),
    
    // Edge cases
    array('test_bool_true', 1, 'Integer 1 vs stored \'1\''),
    array('test_bool_false', 0, 'Integer 0 vs stored \'0\''),
);

$passed = 0;
$total = count($test_cases);

foreach ($test_cases as $i => $test_case) {
    list($option_name, $new_value, $description) = $test_case;
    
    echo "Test " . ($i + 1) . ": $description\n";
    $current = get_option($option_name);
    $current_display = is_array($current) ? json_encode($current) : (is_bool($current) ? ($current ? 'true' : 'false') : "'$current'");
    $new_display = is_array($new_value) ? json_encode($new_value) : (is_bool($new_value) ? ($new_value ? 'true' : 'false') : "'$new_value'");
    echo "  Current: $current_display, New: $new_display\n";
    
    $result = safe_update_option($option_name, $new_value);
    
    if ($result) {
        $passed++;
        echo "  ✅ PASSED\n";
    } else {
        echo "  ❌ FAILED\n";
    }
    echo "\n";
}

echo "==========================================\n";
echo "📊 Test Results: $passed/$total tests passed\n";

if ($passed === $total) {
    echo "🎉 ALL TESTS PASSED! Boolean handling is working correctly.\n";
    echo "✅ Production boolean option update issues should be resolved.\n";
} else {
    echo "⚠️  Some tests failed. Review the implementation.\n";
}

echo "\n";
echo "🔍 Key improvements:\n";
echo "  • Boolean true matches stored '1', 1, or true\n";
echo "  • Boolean false matches stored '0', 0, or false\n";
echo "  • Numeric strings compared as strings ('4' === '4')\n";
echo "  • Mixed type numeric comparison (4 matches '4')\n";
echo "  • Arrays and objects use strict comparison\n";
?>
