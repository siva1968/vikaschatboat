<?php
// Direct JavaScript syntax test with node.js

$jsContent = <<<'EOD'
jQuery(document).ready(function($) {
    // Grade system checkbox change handler
    $('.grade-system-checkbox').on('change', function() {
        updateGradePreview();
    });
    
    // Function to update grade preview based on selected systems
    function updateGradePreview() {
        var selectedSystems = [];
        $('.grade-system-checkbox:checked').each(function() {
            selectedSystems.push($(this).val());
        });
        
        // Update grade preview sections
        $('.grade-preview').hide();
        
        selectedSystems.forEach(function(system) {
            $('#grade-preview-' + system).show();
        });
        
        // Show/hide custom grades section based on whether any system is selected
        if (selectedSystems.length > 0) {
            $('#custom-grades-section').show();
        } else {
            $('#custom-grades-section').hide();
        }
    }
    
    // Initialize preview on page load
    updateGradePreview();

    // Board type change handler
    $('#board-type-select').on('change', function() {
        var selectedBoard = $(this).val();
        
        // Hide all board configs
        $('.board-config').hide();
        
        if (selectedBoard !== 'none') {
            $('#board-config-' + selectedBoard).show();
        }
        
        if (selectedBoard === 'custom') {
            $('#custom-board-section').show();
        } else {
            $('#custom-board-section').hide();
        }
    });

    // Add custom grade
    $('#add-custom-grade').on('click', function() {
        var template = '<div class="edubot-field-item">' +
            '<input type="text" name="academic_config[custom_grades_keys][]" placeholder="Grade Key (e.g. grade_1)" required />' +
            '<input type="text" name="academic_config[custom_grades_labels][]" placeholder="Grade Display Name (e.g. Grade 1)" required />' +
            '<button type="button" class="edubot-remove-btn">Remove</button>' +
            '</div>';
        $('#custom-grades-container').append(template);
    });

    // Add admission cycle
    $('#add-admission-cycle').on('click', function() {
        var index = $('#admission-cycles-container .admission-cycle-item').length;
        var template = '<div class="edubot-field-item admission-cycle-item">' +
            '<input type="text" name="academic_config[admission_cycles][' + index + '][name]" placeholder="Admission Cycle Name" required />' +
            '<input type="date" name="academic_config[admission_cycles][' + index + '][start_date]" />' +
            '<input type="date" name="academic_config[admission_cycles][' + index + '][end_date]" />' +
            '<button type="button" class="edubot-remove-btn">Remove</button>' +
            '</div>';
        $('#admission-cycles-container').append(template);
    });

    // Remove item handler
    $(document).on('click', '.edubot-remove-btn', function() {
        $(this).closest('.edubot-field-item').remove();
    });

    // Update academic year display when type changes
    $('#academic-year-type').on('change', function() {
        // This would make an AJAX call to update the current year display
        // Implementation depends on your AJAX setup
    });
});
EOD;

// Write to temp file
file_put_contents('temp_test.js', $jsContent);

echo "=== Testing JavaScript Syntax with Node.js ===\n";

// Test with node.js if available
$command = 'node -c temp_test.js 2>&1';
$output = shell_exec($command);

if (empty($output)) {
    echo "✅ JavaScript syntax is VALID\n";
    echo "✅ No syntax errors found\n";
} else {
    echo "❌ JavaScript syntax errors:\n";
    echo $output . "\n";
}

// Clean up
unlink('temp_test.js');

echo "\n=== Direct Syntax Test Complete ===\n";
?>
