<?php
// Simulate the comprehensive parsing logic
$message = "I am looking for admission for my sun Sujay for Nursary for the accodamic year 2025-25";
$extracted_data = array();
$message_lower = strtolower($message);

echo "Testing comprehensive parsing...\n\n";

// Extract student name
$student_name = '';
if (preg_match('/for my (?:son|sun|daughter|child)\s+([a-zA-Z]+)\s+for/i', $message, $matches)) {
    $student_name = ucfirst(trim($matches[1]));
}

echo "Extracted name: '$student_name'\n";
echo "Name length: " . strlen($student_name) . "\n";
echo "Name validation (2-20 chars): " . (strlen($student_name) >= 2 && strlen($student_name) <= 20 ? 'PASS' : 'FAIL') . "\n";

if (!empty($student_name) && strlen($student_name) >= 2 && strlen($student_name) <= 20) {
    $extracted_data['student_name'] = $student_name;
    echo "✅ Name added to extracted_data\n";
} else {
    echo "❌ Name NOT added to extracted_data\n";
}

// Extract grade
$grade_patterns = array(
    '/\b(nursery|nursary|pre-?kg|lkg|ukg)\b/i',
    '/\b(?:grade|class)\s*(\d+)\b/i',
    '/\b(\d+)(?:st|nd|rd|th)\s*(?:grade|class)?\b/i'
);

foreach ($grade_patterns as $pattern) {
    if (preg_match($pattern, $message, $matches)) {
        $grade = ucfirst(strtolower($matches[0]));
        if (stripos($grade, 'nursery') !== false || stripos($grade, 'nursary') !== false) $grade = 'Nursery';
        $extracted_data['grade'] = $grade;
        echo "✅ Grade extracted: $grade\n";
        break;
    }
}

// Extract academic year
if (preg_match('/\b(20\d{2}[-\/]?\d{2})\b/', $message, $year_matches)) {
    $year = $year_matches[1];
    if (strpos($year, '-') === false && strpos($year, '/') === false) {
        if (strlen($year) == 6) {
            $year = substr($year, 0, 4) . '-' . substr($year, 4, 2);
        }
    }
    $extracted_data['academic_year'] = $year;
    echo "✅ Academic year extracted: $year\n";
}

echo "\nFinal extracted_data:\n";
print_r($extracted_data);

echo "\nIs extracted_data empty? " . (empty($extracted_data) ? "YES" : "NO") . "\n";
?>
