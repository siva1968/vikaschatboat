<?php
// Quick test to check welcome message loading
// This is a standalone script to test the welcome message

// Simulate the key functions
function fix_message_escaping($message) {
    if (empty($message)) {
        return $message;
    }
    
    // Fix common escaping patterns that occur during save/load cycles
    $fixed = $message;
    
    // Remove excessive backslashes before apostrophes
    $fixed = str_replace("\\\\\\\\'", "'", $fixed);  // \\\\' -> '
    $fixed = str_replace("\\\\\'", "'", $fixed);     // \\' -> '
    $fixed = str_replace("\\'", "'", $fixed);        // \' -> '
    
    // Apply stripslashes if there are still escaped characters
    if (strpos($fixed, '\\') !== false) {
        $fixed = stripslashes($fixed);
    }
    
    return $fixed;
}

// Test different welcome message scenarios
$test_messages = array(
    'Clean message' => "Hi! I'm here to help you with school admissions. Let's get started!",
    'Single escape' => "Hi! I\\'m here to help you with school admissions. Let\\'s get started!",
    'Double escape' => "Hi! I\\\\'m here to help you with school admissions. Let\\\\'s get started!",
    'Mixed escape' => "Hi! I\\\'m here to help you with school admissions. Let\'s get started!"
);

echo "Welcome Message Escaping Test\n";
echo "============================\n\n";

foreach ($test_messages as $label => $message) {
    $fixed = fix_message_escaping($message);
    echo "$label:\n";
    echo "Original: $message\n";
    echo "Fixed:    $fixed\n";
    echo "Length:   " . strlen($fixed) . " chars\n\n";
}

echo "Expected result: Hi! I'm here to help you with school admissions. Let's get started!\n";
