<?php
/**
 * ZeptoMail API Key Fix Test
 * Shows the correct vs incorrect API key format
 */

echo "=== ZeptoMail API Key Fix ===\n\n";

$incorrect_api_key = "Zoho-enczapikey PHtE6r0KRL/ijzJ+oUBV7ffpF8KmNYMt+r9uKghG5YsQA6AKSk1VqIt6lzDm+hciVKQQEf7Pm4I64r+fsrjTJzq5YWcdWGqyqK3sx/VYSPOZsbq6x00Zs1gScEPVU4Lret5u0CLfvN3YNA==";

echo "❌ INCORRECT API Key (from logs):\n";
echo "Length: " . strlen($incorrect_api_key) . " characters\n";
echo "Value: {$incorrect_api_key}\n\n";

// Clean the API key
$correct_api_key = str_replace(array('Zoho-enczapikey ', 'Bearer '), '', $incorrect_api_key);
$correct_api_key = trim($correct_api_key);

echo "✅ CORRECT API Key (cleaned):\n";
echo "Length: " . strlen($correct_api_key) . " characters\n";
echo "Value: {$correct_api_key}\n\n";

echo "🔧 What happens in the plugin:\n";
echo "1. User enters: Zoho-enczapikey PHtE6r0K...\n";
echo "2. Plugin cleans: PHtE6r0K...\n";
echo "3. Plugin adds prefix: Zoho-enczapikey PHtE6r0K...\n";
echo "4. Final header: 'authorization: Zoho-enczapikey PHtE6r0K...'\n\n";

echo "🧪 Test with cleaned API key:\n";
$test_data = array(
    'from' => array('address' => 'noreply@epistemo.in'),
    'to' => array(array('email_address' => array('address' => 'prasad@sampoornadigi.com', 'name' => 'Test'))),
    'subject' => 'API Key Fix Test - ' . date('Y-m-d H:i:s'),
    'htmlbody' => '<div><b>API Key Fix Test</b><br>This email tests the corrected API key format.<br>Timestamp: ' . date('Y-m-d H:i:s') . '</div>'
);

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.zeptomail.in/v1.1/email",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($test_data),
    CURLOPT_HTTPHEADER => array(
        "accept: application/json",
        "authorization: Zoho-enczapikey {$correct_api_key}",
        "content-type: application/json",
    ),
));

$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$err = curl_error($curl);
curl_close($curl);

echo "📧 Test Result:\n";
echo "HTTP Code: {$http_code}\n";

if ($err) {
    echo "❌ cURL Error: {$err}\n";
} else {
    $decoded = json_decode($response, true);
    if ($http_code == 200 || $http_code == 201) {
        echo "✅ SUCCESS: API key fix working!\n";
        echo "Response: " . ($decoded['data'][0]['message'] ?? 'N/A') . "\n";
        echo "Request ID: " . ($decoded['request_id'] ?? 'N/A') . "\n";
    } else {
        echo "❌ FAILED: HTTP {$http_code}\n";
        echo "Response: {$response}\n";
    }
}

echo "\n🎯 WordPress Fix Applied:\n";
echo "• Added API key cleaning in test method\n";
echo "• Added API key cleaning in save method\n";
echo "• Now removes 'Zoho-enczapikey ' prefix automatically\n";
echo "• Prevents double-prefix issues\n\n";

echo "📝 Instructions for WordPress:\n";
echo "1. In WordPress admin, enter ONLY the encoded part:\n";
echo "   {$correct_api_key}\n";
echo "2. Do NOT include 'Zoho-enczapikey ' prefix\n";
echo "3. Save and test - should now work!\n";

?>
