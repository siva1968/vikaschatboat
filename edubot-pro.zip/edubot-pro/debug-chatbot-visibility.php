<?php
/**
 * Debug script to test chatbot visibility and JavaScript loading
 */

// Test 1: Check if chatbot HTML is being rendered
echo "<h2>EduBot Chatbot Debug Test</h2>";

// Test 2: Add a simple test widget to see if it appears
?>
<style>
    .debug-chatbot-test {
        position: fixed;
        bottom: 20px;
        right: 300px;
        background: red;
        color: white;
        padding: 15px;
        border-radius: 10px;
        z-index: 999999;
        font-family: Arial, sans-serif;
    }
</style>

<div class="debug-chatbot-test">
    <strong>Debug Test Widget</strong><br>
    If you see this, CSS positioning works!
</div>

<script>
jQuery(document).ready(function($) {
    console.log('=== EduBot Debug Test ===');
    
    // Check if main widget exists
    var widget = $('#edubot-chatbot-widget');
    console.log('Widget found:', widget.length > 0);
    console.log('Widget element:', widget);
    
    // Check if toggle button exists
    var toggle = $('#edubot-chat-toggle');
    console.log('Toggle found:', toggle.length > 0);
    console.log('Toggle element:', toggle);
    
    // Check if container exists
    var container = $('#edubot-chat-container');
    console.log('Container found:', container.length > 0);
    console.log('Container element:', container);
    
    // Check if EduBotChatWidget is defined
    console.log('EduBotChatWidget defined:', typeof window.EduBotChatWidget !== 'undefined');
    
    // Check if jQuery is working
    console.log('jQuery version:', $.fn.jquery);
    
    // Test manual toggle
    if (toggle.length > 0) {
        console.log('Adding manual click handler for testing');
        toggle.off('click').on('click', function(e) {
            e.preventDefault();
            console.log('Toggle clicked!');
            if (container.length > 0) {
                if (container.is(':visible')) {
                    container.hide();
                    console.log('Container hidden');
                } else {
                    container.show();
                    console.log('Container shown');
                }
            }
        });
    }
    
    // Show current visibility status
    if (container.length > 0) {
        console.log('Container display style:', container.css('display'));
        console.log('Container visible:', container.is(':visible'));
    }
    
    console.log('=== End Debug Test ===');
});
</script>

<p><strong>Instructions:</strong></p>
<ol>
    <li>Open browser developer tools (F12)</li>
    <li>Look at the Console tab for debug messages</li>
    <li>Look for the red "Debug Test Widget" on the right side</li>
    <li>Try clicking the chatbot toggle button</li>
    <li>Check console for any JavaScript errors</li>
</ol>
