<?php
/**
 * Standalone ZeptoMail SMTP Test (No WordPress Required)
 * This mimics your exact configuration to test connectivity
 */

echo "=== ZeptoMail SMTP Test (Standalone) ===\n";

// Test basic socket connectivity first
$host = "smtp.zeptomail.in";
$port = 587;

echo "1. Testing socket connectivity to {$host}:{$port}...\n";
$socket = @fsockopen($host, $port, $errno, $errstr, 15);
if ($socket) {
    echo "✅ Socket connection successful!\n";
    fclose($socket);
} else {
    echo "❌ Socket connection failed: {$errstr} ({$errno})\n";
}

// Test port 465 as well
echo "\n2. Testing socket connectivity to {$host}:465...\n";
$socket465 = @fsockopen($host, 465, $errno465, $errstr465, 15);
if ($socket465) {
    echo "✅ Socket connection to port 465 successful!\n";
    fclose($socket465);
} else {
    echo "❌ Socket connection to port 465 failed: {$errstr465} ({$errno465})\n";
}

// Test SMTP conversation manually
echo "\n3. Testing SMTP protocol conversation...\n";

$socket = @fsockopen($host, $port, $errno, $errstr, 15);
if ($socket) {
    echo "📧 Connected to SMTP server, testing protocol...\n";
    
    // Read initial response
    $response = fgets($socket, 512);
    echo "Server: " . trim($response) . "\n";
    
    // Send EHLO
    fputs($socket, "EHLO localhost\r\n");
    $response = fgets($socket, 512);
    echo "EHLO Response: " . trim($response) . "\n";
    
    // Check for STARTTLS support
    fputs($socket, "HELP\r\n");
    $help_response = fgets($socket, 512);
    echo "HELP Response: " . trim($help_response) . "\n";
    
    // Send QUIT
    fputs($socket, "QUIT\r\n");
    $response = fgets($socket, 512);
    echo "QUIT Response: " . trim($response) . "\n";
    
    fclose($socket);
    echo "✅ SMTP protocol test completed!\n";
} else {
    echo "❌ Could not establish SMTP connection for protocol test\n";
}

echo "\n=== WordPress Plugin Debugging ===\n";
echo "Based on your console log, the WordPress AJAX test is failing.\n";
echo "Your test data shows: {success: false, data: {...}}\n\n";

echo "🔍 Debugging steps for WordPress:\n";
echo "1. Check the actual AJAX response data\n";
echo "2. Verify the password decryption is working\n";
echo "3. Ensure the enhanced SMTP method is being used\n\n";

echo "📧 Your ZeptoMail credentials:\n";
echo "Host: smtp.zeptomail.in\n";
echo "Username: emailapikey\n";
echo "Password: [ENCRYPTED - length: " . strlen('PHtE6r0KRL/ijzJ+oUBV7ffpF8KmNYMt+r9uKghG5YsQA6AKSk1VqIt6lzDm+hciVKQQEf7Pm4I64r+fsrjTJzq5YWcdWGqyqK3sx/VYSPOZsbq6x00Zs1gScEPVU4Lret5u0CLfvN3YNA==') . " chars]\n";
echo "Port: 587 (with fallback to 465)\n\n";

echo "✅ Network connectivity is confirmed working.\n";
echo "❌ The issue is likely in the WordPress plugin configuration or password handling.\n\n";

echo "🔧 Next steps:\n";
echo "1. Check WordPress error logs for detailed SMTP errors\n";
echo "2. Verify the password is being decrypted correctly in WordPress\n";
echo "3. Test with the enhanced multi-port SMTP method we implemented\n";

?>
