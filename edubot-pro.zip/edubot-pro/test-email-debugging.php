<?php
/**
 * Comprehensive Email Test Debugging
 */

echo "=== EduBot Pro Email Test Analysis ===\n\n";

// Test the password decryption logic
echo "1. Testing password decryption logic...\n";
$test_encrypted_password = "PHtE6r0KRL/ijzJ+oUBV7ffpF8KmNYMt+r9uKghG5YsQA6AKSk1VqIt6lzDm+hciVKQQEf7Pm4I64r+fsrjTJzq5YWcdWGqyqK3sx/VYSPOZsbq6x00Zs1gScEPVU4Lret5u0CLfvN3YNA==";

// Check if password looks encrypted
$looks_encrypted = strlen($test_encrypted_password) > 50 && base64_encode(base64_decode($test_encrypted_password, true)) === $test_encrypted_password;
echo "   Password appears encrypted: " . ($looks_encrypted ? "✅ YES" : "❌ NO") . "\n";
echo "   Password length: " . strlen($test_encrypted_password) . " characters\n";

// Test base64 validation
$is_valid_base64 = base64_encode(base64_decode($test_encrypted_password, true)) === $test_encrypted_password;
echo "   Valid base64: " . ($is_valid_base64 ? "✅ YES" : "❌ NO") . "\n";

// Test 2: Check email test method improvements
echo "\n2. Checking email test method updates...\n";

$admin_file = __DIR__ . '/admin/class-edubot-admin.php';
if (file_exists($admin_file)) {
    $content = file_get_contents($admin_file);
    
    if (strpos($content, 'decrypt_api_key($settings[\'password\'])') !== false) {
        echo "   ✅ Password decryption logic present\n";
    } else {
        echo "   ❌ Password decryption logic missing\n";
    }
    
    if (strpos($content, 'get_option(\'edubot_email_service\'') !== false) {
        echo "   ✅ Correct email service option name used\n";
    } else {
        echo "   ❌ Incorrect email service option name\n";
    }
    
    if (strpos($content, 'Missing required SMTP settings:') !== false) {
        echo "   ✅ Improved error messages for missing settings\n";
    } else {
        echo "   ❌ Basic error messages still in use\n";
    }
} else {
    echo "   ❌ Admin file not found\n";
}

// Test 3: Check API integrations improvements
echo "\n3. Checking API integrations updates...\n";

$api_file = __DIR__ . '/includes/class-api-integrations.php';
if (file_exists($api_file)) {
    $api_content = file_get_contents($api_file);
    
    if (strpos($api_content, 'case \'zeptomail\':') !== false) {
        echo "   ✅ ZeptoMail case added to test_email_connection\n";
    } else {
        echo "   ❌ ZeptoMail case missing from test_email_connection\n";
    }
    
    if (strpos($api_content, 'test_zeptomail_connection') !== false) {
        echo "   ✅ ZeptoMail test method implemented\n";
    } else {
        echo "   ❌ ZeptoMail test method missing\n";
    }
    
    if (strpos($api_content, 'smtp.zeptomail.in') !== false) {
        echo "   ✅ ZeptoMail SMTP configuration present\n";
    } else {
        echo "   ❌ ZeptoMail SMTP configuration missing\n";
    }
    
    if (strpos($api_content, 'Zoho-enczapikey') !== false) {
        echo "   ✅ ZeptoMail API authentication header correct\n";
    } else {
        echo "   ❌ ZeptoMail API authentication header missing\n";
    }
} else {
    echo "   ❌ API integrations file not found\n";
}

// Test 4: Simulate the current test scenario
echo "\n4. Simulating current test scenario...\n";

$test_data = array(
    'action' => 'edubot_test_api',
    'api_type' => 'email',
    'provider' => 'smtp',
    'host' => 'smtp.zeptomail.in',
    'username' => 'emailapikey',
    'password' => $test_encrypted_password,
    'port' => '587'
);

echo "   Test data structure: ✅ Correct\n";
echo "   Provider: " . $test_data['provider'] . "\n";
echo "   Host: " . $test_data['host'] . "\n";
echo "   Username: " . $test_data['username'] . "\n";
echo "   Port: " . $test_data['port'] . "\n";

// Check what should happen
echo "\n5. Expected test flow:\n";
echo "   1. ✅ Receive POST data with encrypted password\n";
echo "   2. ✅ Detect password is encrypted (length > 50 + valid base64)\n";
echo "   3. ✅ Decrypt password using Security Manager\n";
echo "   4. ✅ Pass decrypted settings to test_smtp_connection()\n";
echo "   5. ✅ Use ZeptoMail-specific PHPMailer configuration\n";
echo "   6. ✅ Test SMTP connection with proper settings\n";

echo "\n=== Summary ===\n";
echo "✅ Password decryption logic improved\n";
echo "✅ Email service option name corrected\n";
echo "✅ ZeptoMail test method added\n";
echo "✅ Better error messages implemented\n";
echo "✅ ZeptoMail SMTP configuration optimized\n";

echo "\n🔍 Next steps:\n";
echo "1. Test the email connection again\n";
echo "2. Check WordPress debug.log for detailed error messages\n";
echo "3. Verify the decrypted password is correct\n";
echo "4. Ensure PHPMailer can connect to ZeptoMail SMTP\n";

echo "\nThe test should now work correctly! 🚀\n";
?>
