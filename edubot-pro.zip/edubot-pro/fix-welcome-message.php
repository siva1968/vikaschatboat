<?php
/**
 * Quick fix for the welcome message escaping issue
 * This will update the WordPress option with clean text
 */

// WordPress environment check
if (!defined('ABSPATH')) {
    // Standalone execution - for testing purposes
    die('This script should be run from WordPress admin or with WordPress loaded.');
}

// Clean welcome message without any escaping
$clean_welcome_message = "Hi! I'm here to help you with school admissions. Let's get started!";

// Update the WordPress option
$result = update_option('edubot_welcome_message', $clean_welcome_message);

if ($result) {
    echo "✅ Welcome message updated successfully!<br>";
    echo "New message: " . esc_html($clean_welcome_message) . "<br>";
} else {
    echo "⚠️ Message was already correct or update failed.<br>";
}

// Also check and display current value
$current_message = get_option('edubot_welcome_message', '');
echo "<br>Current stored message: " . esc_html($current_message) . "<br>";

// Check if there are any escape characters
if (strpos($current_message, '\\') !== false) {
    echo "❌ Still contains backslashes - may need manual intervention<br>";
} else {
    echo "✅ No backslashes detected<br>";
}
?>
