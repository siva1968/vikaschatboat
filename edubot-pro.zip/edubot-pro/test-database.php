<?php
/**
 * Test script to verify EduBot Pro database tables and Security Manager functionality
 */

// This script should be run from the WordPress environment
// You can run it by placing it in your theme directory and accessing it via browser

// Prevent direct access if not in WordPress context
if (!function_exists('add_action')) {
    die('This script must be run within WordPress');
}

echo "<h2>EduBot Pro Database Test</h2>";

// Test 1: Check if all required tables exist
echo "<h3>1. Database Tables Check</h3>";

global $wpdb;

$required_tables = array(
    'edubot_security_log',
    'edubot_visitor_analytics', 
    'edubot_visitors',
    'edubot_applications',
    'edubot_analytics',
    'edubot_sessions',
    'edubot_school_configs'
);

$all_tables_exist = true;

foreach ($required_tables as $table_name) {
    $full_table_name = $wpdb->prefix . $table_name;
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$full_table_name'");
    
    if ($table_exists == $full_table_name) {
        echo "<span style='color: green;'>✓</span> $full_table_name exists<br>";
    } else {
        echo "<span style='color: red;'>✗</span> $full_table_name MISSING<br>";
        $all_tables_exist = false;
    }
}

if ($all_tables_exist) {
    echo "<p style='color: green;'><strong>All required tables exist!</strong></p>";
} else {
    echo "<p style='color: red;'><strong>Some tables are missing. Please run the database repair.</strong></p>";
}

// Test 2: Test Security Manager functionality
echo "<h3>2. Security Manager Test</h3>";

if (!class_exists('EduBot_Security_Manager')) {
    // Try to load the class
    $security_manager_path = dirname(__FILE__) . '/includes/class-security-manager.php';
    if (file_exists($security_manager_path)) {
        require_once $security_manager_path;
    }
}

if (class_exists('EduBot_Security_Manager')) {
    $security_manager = new EduBot_Security_Manager();
    
    // Test URL validation
    $test_urls = array(
        'https://example.com/logo.png' => true,
        'http://example.com/image.jpg' => true,
        'javascript:alert("xss")' => false,
        'data:image/png;base64,abc' => false,
        'ftp://example.com/file.txt' => false,
        '' => false,
        'not-a-url' => false
    );
    
    echo "<h4>URL Validation Test:</h4>";
    $all_url_tests_passed = true;
    
    foreach ($test_urls as $url => $expected) {
        $result = $security_manager->is_safe_url($url);
        $status = ($result === $expected) ? 'PASS' : 'FAIL';
        $color = ($result === $expected) ? 'green' : 'red';
        
        echo "<span style='color: $color;'>$status</span> - URL: '$url' - Expected: " . ($expected ? 'safe' : 'unsafe') . " - Got: " . ($result ? 'safe' : 'unsafe') . "<br>";
        
        if ($result !== $expected) {
            $all_url_tests_passed = false;
        }
    }
    
    if ($all_url_tests_passed) {
        echo "<p style='color: green;'><strong>All URL validation tests passed!</strong></p>";
    } else {
        echo "<p style='color: red;'><strong>Some URL validation tests failed!</strong></p>";
    }
    
    // Test security logging (if table exists)
    $security_table = $wpdb->prefix . 'edubot_security_log';
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$security_table'");
    
    if ($table_exists == $security_table) {
        echo "<h4>Security Logging Test:</h4>";
        
        try {
            $security_manager->log_security_event('test_event', array('test' => 'data'));
            echo "<span style='color: green;'>✓</span> Security logging test successful<br>";
            
            // Check if the log entry was created
            $log_count = $wpdb->get_var("SELECT COUNT(*) FROM $security_table WHERE event_type = 'test_event'");
            echo "<span style='color: green;'>✓</span> Found $log_count test log entries<br>";
            
        } catch (Exception $e) {
            echo "<span style='color: red;'>✗</span> Security logging failed: " . $e->getMessage() . "<br>";
        }
    } else {
        echo "<span style='color: orange;'>⚠</span> Security table missing, cannot test logging<br>";
    }
    
} else {
    echo "<span style='color: red;'>✗</span> EduBot_Security_Manager class not found<br>";
}

// Test 3: Plugin activation status
echo "<h3>3. Plugin Status</h3>";

if (is_plugin_active('edubot-pro/edubot-pro.php')) {
    echo "<span style='color: green;'>✓</span> EduBot Pro plugin is active<br>";
} else {
    echo "<span style='color: red;'>✗</span> EduBot Pro plugin is not active<br>";
}

echo "<h3>Test Complete</h3>";
echo "<p>If any tests failed, please check the error logs and run the database repair function.</p>";
?>
