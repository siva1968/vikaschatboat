<?php
/**
 * Debug WordPress Email Test
 * Simulates the exact WordPress plugin test process
 */

echo "=== WordPress Email Test Debug ===\n\n";

// Simulate the data that would be sent via AJAX
$test_data = array(
    'action' => 'edubot_test_api',
    'api_type' => 'email',
    'provider' => 'smtp',
    'host' => 'smtp.zeptomail.in',
    'port' => 587,
    'username' => 'emailapikey',
    'password' => 'PHtE6r0KRL/ijzJ+oUBV7ffpF8KmNYMt+r9uKghG5YsQA6AKSk1VqIt6lzDm+hciVKQQEf7Pm4I64r+fsrjTJzq5YWcdWGqyqK3sx/VYSPOZsbq6x00Zs1gScEPVU4Lret5u0CLfvN3YNA==',
    'from_address' => 'noreply@epistemo.in',
    'from_name' => 'EduBot Test'
);

echo "📧 Test Configuration:\n";
foreach ($test_data as $key => $value) {
    if ($key === 'password') {
        echo "  {$key}: [ENCRYPTED - " . strlen($value) . " chars]\n";
    } else {
        echo "  {$key}: {$value}\n";
    }
}

echo "\n🔍 Password Analysis:\n";
$password = $test_data['password'];
echo "Length: " . strlen($password) . " characters\n";
echo "Is base64? " . (base64_encode(base64_decode($password, true)) === $password ? "✅ Yes" : "❌ No") . "\n";

if (base64_encode(base64_decode($password, true)) === $password) {
    echo "Decoded length: " . strlen(base64_decode($password)) . " characters\n";
    echo "First 20 chars of decoded: " . substr(base64_decode($password), 0, 20) . "...\n";
}

echo "\n🚨 Common Issues to Check:\n";
echo "1. Password decryption failing in WordPress\n";
echo "2. Security manager not loading properly\n";
echo "3. SMTP configuration not using enhanced multi-port testing\n";
echo "4. PHPMailer timeout or SSL issues\n";

echo "\n📝 WordPress Error Log Checks:\n";
echo "Look for these patterns in your WordPress error logs:\n";
echo "• 'EduBot: Email test - provider: smtp'\n";
echo "• 'EduBot: Email test - saved settings:'\n";
echo "• 'EduBot: SMTP validation - host:'\n";
echo "• 'EduBot: Failed to decrypt email password:'\n";
echo "• 'EduBot Admin: API test for email - FAILED'\n";

echo "\n🔧 Next Steps:\n";
echo "1. Check WordPress admin error logs during the test\n";
echo "2. Verify the enhanced SMTP test method is being called\n";
echo "3. Test with port 465 if 587 fails\n";
echo "4. Ensure ZeptoMail credentials are correct\n";

echo "\n✅ Network connectivity confirmed working (ports 587 & 465)\n";
echo "❌ Issue is in WordPress plugin configuration or password handling\n";

// Test if we can manually decode the password
echo "\n🔓 Manual Password Test:\n";
try {
    $decoded = base64_decode($password, true);
    if ($decoded !== false) {
        echo "✅ Password can be base64 decoded\n";
        echo "Decoded starts with: " . substr($decoded, 0, 10) . "...\n";
    } else {
        echo "❌ Password is not valid base64\n";
    }
} catch (Exception $e) {
    echo "❌ Error decoding password: " . $e->getMessage() . "\n";
}

echo "\n📧 Test Email Settings Summary:\n";
echo "Host: smtp.zeptomail.in (✅ Reachable)\n";
echo "Port: 587 (✅ Working) / 465 (✅ Working as fallback)\n";
echo "Username: emailapikey\n";
echo "Password: Encrypted (needs WordPress decryption)\n";
echo "From: noreply@epistemo.in\n";

?>
