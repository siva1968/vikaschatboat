<?php
/**
 * String Escaping Fix for Welcome Messages
 * 
 * This script fixes the backslash escaping issue in welcome messages
 */

if (!defined('ABSPATH')) {
    echo "String Escaping Analysis and Fix\n";
    echo "===============================\n\n";
}

// Test the current problem
$test_message = "Hi! I\\\\\\\'m here to help you with school admissions. Let\\\'s get started!";
echo "Current problematic message:\n";
echo "Raw: " . $test_message . "\n";
echo "Display: " . stripslashes($test_message) . "\n\n";

// Demonstrate the fix
function fix_welcome_message_escaping($message) {
    // Remove excessive backslashes but preserve intentional ones
    $fixed = $message;
    
    // Fix the specific pattern we're seeing
    $fixed = str_replace("\\\\\\\\'", "'", $fixed);  // Remove \\\\\\' -> '
    $fixed = str_replace("\\\\\'", "'", $fixed);     // Remove \\' -> '
    $fixed = str_replace("\\'", "'", $fixed);        // Remove \' -> '
    
    // Make sure we don't double-fix
    if ($fixed === $message) {
        // Try WordPress's stripslashes_deep equivalent for single string
        $fixed = stripslashes($message);
    }
    
    return $fixed;
}

$fixed_message = fix_welcome_message_escaping($test_message);
echo "Fixed message:\n";
echo "Result: " . $fixed_message . "\n\n";

// Test validation
$expected = "Hi! I'm here to help you with school admissions. Let's get started!";
echo "Validation:\n";
echo "Expected: " . $expected . "\n";
echo "Got:      " . $fixed_message . "\n";
echo "Match:    " . ($fixed_message === $expected ? "✅ YES" : "❌ NO") . "\n\n";

echo "Fix Implementation Plan:\n";
echo "========================\n";
echo "1. Add stripslashes() to message processing\n";
echo "2. Prevent double-escaping during save\n";
echo "3. Clean existing data on load\n";
echo "4. Add validation to prevent future issues\n\n";

echo "Testing different escaping patterns:\n";
echo "====================================\n";

$test_cases = [
    "Hi! I'm here to help!",                           // Normal
    "Hi! I\\'m here to help!",                         // Single escape
    "Hi! I\\\\\'m here to help!",                      // Double escape  
    "Hi! I\\\\\\\\\'m here to help!",                  // Triple escape
    "Hi! I\\\\\\\\\\\\\\\'m here to help!"             // Excessive escape
];

foreach ($test_cases as $index => $test) {
    echo "Test " . ($index + 1) . ":\n";
    echo "  Input:  " . $test . "\n";
    echo "  Fixed:  " . fix_welcome_message_escaping($test) . "\n";
    echo "  Method: ";
    
    if (strpos($test, "\\\\\\\\") !== false) {
        echo "Excessive escaping detected\n";
    } elseif (strpos($test, "\\\\") !== false) {
        echo "Double escaping detected\n";
    } elseif (strpos($test, "\\'") !== false) {
        echo "Single escaping detected\n";
    } else {
        echo "No escaping issues\n";
    }
    echo "\n";
}

echo "Solution Ready! ✅\n";
