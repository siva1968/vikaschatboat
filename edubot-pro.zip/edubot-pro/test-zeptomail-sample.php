<?php

require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;

echo "=== ZeptoMail SMTP Test with Your Credentials ===\n";

$mail = new PHPMailer();
$mail->Encoding = "base64";
$mail->SMTPAuth = true;
$mail->Host = "smtp.zeptomail.in";
$mail->Port = 587;
$mail->Username = "emailapikey";
$mail->Password = 'PHtE6r0KRL/ijzJ+oUBV7ffpF8KmNYMt+r9uKghG5YsQA6AKSk1VqIt6lzDm+hciVKQQEf7Pm4I64r+fsrjTJzq5YWcdWGqyqK3sx/VYSPOZsbq6x00Zs1gScEPVU4Lret5u0CLfvN3YNA==';
$mail->SMTPSecure = 'TLS';
$mail->isSMTP();
$mail->IsHTML(true);
$mail->CharSet = "UTF-8";
$mail->From = "noreply@epistemo.in";
$mail->addAddress('prasad@sampoornadigi.com');
$mail->Body="Test email sent successfully.";
$mail->Subject="Test Email";
$mail->SMTPDebug = 1;
$mail->Debugoutput = function($str, $level) {echo "debug level $level; message: $str"; echo "<br>";};

echo "Attempting to send test email...\n\n";

if(!$mail->Send()) {
    echo "❌ Mail sending failed: " . $mail->ErrorInfo . "\n";
} else {
    echo "✅ Successfully sent!\n";
}
?>
