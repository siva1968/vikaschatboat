<?php
/**
 * Test script to verify branding integration
 * Run this in WordPress to test if branding colors are being loaded correctly
 */

// Simulate WordPress environment for testing
if (!defined('ABSPATH')) {
    echo "This script must be run within WordPress context.\n";
    echo "Add this code to a WordPress page or test it via WordPress admin.\n";
    exit;
}

// Test branding manager
require_once plugin_dir_path(__FILE__) . 'includes/class-branding-manager.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-school-config.php';

echo "<h2>EduBot Branding Test</h2>\n";

$branding_manager = new EduBot_Branding_Manager();

echo "<h3>WordPress Options Test:</h3>\n";
echo "Primary Color: " . get_option('edubot_primary_color', 'NOT SET') . "<br>\n";
echo "Secondary Color: " . get_option('edubot_secondary_color', 'NOT SET') . "<br>\n";
echo "School Logo: " . get_option('edubot_school_logo', 'NOT SET') . "<br>\n";

echo "<h3>Branding Manager Color Scheme:</h3>\n";
$colors = $branding_manager->get_color_scheme();
echo "Primary: " . $colors['primary'] . "<br>\n";
echo "Secondary: " . $colors['secondary'] . "<br>\n";

echo "<h3>Logo HTML:</h3>\n";
$logo_html = $branding_manager->get_logo_html('small');
if ($logo_html) {
    echo $logo_html . "<br>\n";
} else {
    echo "No logo available<br>\n";
}

echo "<h3>Custom CSS Sample:</h3>\n";
echo "<pre>" . esc_html($branding_manager->generate_custom_css()) . "</pre>\n";

echo "<h3>Shortcode Test:</h3>\n";
echo "Testing shortcode render...<br>\n";
echo do_shortcode('[edubot_chatbot]');
?>
