<?php
/**
 * ZeptoMail SMTP Test using WordPress PHPMailer
 * 
 * This test script uses the same PHPMailer that WordPress uses,
 * so it should match the plugin behavior exactly.
 */

// Simulate WordPress environment paths
define('ABSPATH', 'D:/xampp/htdocs/wordpress/'); // Adjust this to your WordPress path

// Check if WordPress PHPMailer exists
$phpmailer_path = ABSPATH . 'wp-includes/PHPMailer/PHPMailer.php';
$smtp_path = ABSPATH . 'wp-includes/PHPMailer/SMTP.php';
$exception_path = ABSPATH . 'wp-includes/PHPMailer/Exception.php';

echo "=== ZeptoMail SMTP Test with WordPress PHPMailer ===\n";
echo "Looking for WordPress PHPMailer at: {$phpmailer_path}\n\n";

if (file_exists($phpmailer_path)) {
    require_once $phpmailer_path;
    require_once $smtp_path;
    require_once $exception_path;
    
    echo "✅ WordPress PHPMailer found and loaded\n\n";
    
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    
    try {
        echo "🔧 Configuring SMTP settings...\n";
        
        $mail->isSMTP();
        $mail->Host = "smtp.zeptomail.in";
        $mail->SMTPAuth = true;
        $mail->Username = "emailapikey";
        $mail->Password = 'PHtE6r0KRL/ijzJ+oUBV7ffpF8KmNYMt+r9uKghG5YsQA6AKSk1VqIt6lzDm+hciVKQQEf7Pm4I64r+fsrjTJzq5YWcdWGqyqK3sx/VYSPOZsbq6x00Zs1gScEPVU4Lret5u0CLfvN3YNA==';
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->Timeout = 20;
        
        // ZeptoMail specific optimizations
        $mail->Encoding = 'base64';
        $mail->CharSet = 'UTF-8';
        $mail->isHTML(true);
        
        // SSL options for compatibility
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        
        // Enable debug output
        $mail->SMTPDebug = 2;
        $mail->Debugoutput = function($str, $level) {
            echo "[DEBUG {$level}] {$str}\n";
        };
        
        // Set email content
        $mail->setFrom('noreply@epistemo.in', 'EduBot Test');
        $mail->addAddress('prasad@sampoornadigi.com', 'Test Recipient');
        $mail->Subject = 'ZeptoMail SMTP Test - ' . date('Y-m-d H:i:s');
        $mail->Body = '<h2>Test Email</h2><p>This email was sent successfully using ZeptoMail SMTP with WordPress PHPMailer.</p><p>Timestamp: ' . date('Y-m-d H:i:s') . '</p>';
        
        echo "📧 Attempting to send test email...\n\n";
        
        if ($mail->send()) {
            echo "\n✅ SUCCESS! Email sent successfully!\n";
            echo "📧 Email sent to: prasad@sampoornadigi.com\n";
            echo "🕒 Timestamp: " . date('Y-m-d H:i:s') . "\n";
        } else {
            echo "\n❌ FAILED! Could not send email.\n";
            echo "Error: " . $mail->ErrorInfo . "\n";
        }
        
    } catch (Exception $e) {
        echo "\n❌ EXCEPTION: " . $e->getMessage() . "\n";
    }
    
} else {
    echo "❌ WordPress PHPMailer not found at expected location.\n";
    echo "Please update the ABSPATH to point to your WordPress installation.\n";
    echo "Current path: {$phpmailer_path}\n\n";
    
    // Alternative: Try to use system PHPMailer if available
    echo "Trying to use system PHPMailer...\n";
    
    if (class_exists('PHPMailer')) {
        echo "✅ System PHPMailer found\n";
        
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = "smtp.zeptomail.in";
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->Username = "emailapikey";
        $mail->Password = 'PHtE6r0KRL/ijzJ+oUBV7ffpF8KmNYMt+r9uKghG5YsQA6AKSk1VqIt6lzDm+hciVKQQEf7Pm4I64r+fsrjTJzq5YWcdWGqyqK3sx/VYSPOZsbq6x00Zs1gScEPVU4Lret5u0CLfvN3YNA==';
        $mail->SMTPSecure = 'tls';
        $mail->Encoding = "base64";
        $mail->CharSet = "UTF-8";
        $mail->isHTML(true);
        $mail->SMTPDebug = 1;
        
        $mail->From = "noreply@epistemo.in";
        $mail->addAddress('prasad@sampoornadigi.com');
        $mail->Subject = "ZeptoMail Test - " . date('Y-m-d H:i:s');
        $mail->Body = "Test email sent successfully using system PHPMailer. Timestamp: " . date('Y-m-d H:i:s');
        
        if (!$mail->send()) {
            echo "❌ Mail sending failed: " . $mail->ErrorInfo . "\n";
        } else {
            echo "✅ Successfully sent using system PHPMailer!\n";
        }
    } else {
        echo "❌ No PHPMailer found. Please install PHPMailer or update WordPress path.\n";
    }
}

echo "\n=== Test Complete ===\n";
?>
