<?php
// Test the name extraction pattern
$message = "I am looking for admission for my sun Sujay for Nursary for the accodamic year 2025-25";

echo "Testing message: $message\n\n";

// Pattern 1: "for my son/daughter/child NAME for/in CLASS" (handle typos like "sun")
if (preg_match('/for my (?:son|sun|daughter|child)\s+([a-zA-Z]+)\s+for/i', $message, $matches)) {
    $student_name = ucfirst(trim($matches[1]));
    echo "Pattern 1 matched: $student_name\n";
    print_r($matches);
} else {
    echo "Pattern 1 did not match\n";
}

// Check what the pattern sees
echo "\nPattern breakdown:\n";
echo "- 'for my' found at: " . strpos(strtolower($message), 'for my') . "\n";
echo "- 'sun' found at: " . strpos(strtolower($message), 'sun') . "\n";
echo "- 'sujay' found at: " . strpos(strtolower($message), 'sujay') . "\n";
echo "- 'for' after name found at: " . strpos(strtolower($message), 'for', 35) . "\n";

// Test all patterns
echo "\nTesting all patterns:\n";

$patterns = [
    1 => '/for my (?:son|sun|daughter|child)\s+([a-zA-Z]+)\s+for/i',
    2 => '/my (?:son|sun|daughter|child)\s+([a-zA-Z]+)\s+(?:needs|wants|requires)/i',
    3 => '/my (?:son|sun|daughter|child)\s+([a-zA-Z]+)/i',
    4 => '/child named\s+([a-zA-Z]+)/i',
    5 => '/admission for\s+([a-zA-Z]+)(?:\s|$)/i'
];

foreach ($patterns as $num => $pattern) {
    if (preg_match($pattern, $message, $matches)) {
        echo "Pattern $num matched: " . $matches[1] . "\n";
        break;
    } else {
        echo "Pattern $num did not match\n";
    }
}
?>
