<?php
/**
 * Test Email Settings Retrieval for API Testing
 */

echo "=== Email Settings Retrieval Test ===\n\n";

// Mock WordPress functions for testing
function get_option($option_name, $default = '') {
    $mock_options = array(
        'edubot_email_provider' => 'smtp',
        'edubot_smtp_host' => 'smtp.zeptomail.in',
        'edubot_smtp_port' => 587,
        'edubot_smtp_username' => 'emailapikey',
        'edubot_smtp_password' => 'encrypted_password_here',
        'edubot_email_api_key' => '',
        'edubot_email_domain' => ''
    );
    
    return isset($mock_options[$option_name]) ? $mock_options[$option_name] : $default;
}

// Test the fixed logic
echo "1. Testing saved email settings retrieval:\n";

$saved_settings = array(
    'provider' => get_option('edubot_email_provider', ''),
    'host' => get_option('edubot_smtp_host', ''),
    'port' => get_option('edubot_smtp_port', 587),
    'username' => get_option('edubot_smtp_username', ''),
    'password' => get_option('edubot_smtp_password', ''),
    'api_key' => get_option('edubot_email_api_key', ''),
    'domain' => get_option('edubot_email_domain', '')
);

echo "Saved settings:\n";
foreach ($saved_settings as $key => $value) {
    if ($key === 'password') {
        echo "  $key: " . (empty($value) ? '[EMPTY]' : '[ENCRYPTED]') . "\n";
    } else {
        echo "  $key: " . (empty($value) ? '[EMPTY]' : $value) . "\n";
    }
}

echo "\n2. Testing API test scenario (provider only in POST):\n";

// Simulate the API test POST data
$_POST = array(
    'provider' => 'smtp',
    'api_key' => '',
    'domain' => ''
);

$settings = array(
    'provider' => !empty($_POST['provider']) ? $_POST['provider'] : $saved_settings['provider'],
    'api_key' => isset($_POST['api_key']) ? $_POST['api_key'] : $saved_settings['api_key'],
    'domain' => isset($_POST['domain']) ? $_POST['domain'] : $saved_settings['domain'],
    'host' => isset($_POST['host']) ? $_POST['host'] : $saved_settings['host'],
    'port' => isset($_POST['port']) ? (int)$_POST['port'] : $saved_settings['port'],
    'username' => isset($_POST['username']) ? $_POST['username'] : $saved_settings['username'],
    'password' => isset($_POST['password']) ? $_POST['password'] : $saved_settings['password']
);

echo "Merged settings for API test:\n";
foreach ($settings as $key => $value) {
    if ($key === 'password') {
        echo "  $key: " . (empty($value) ? '[EMPTY]' : '[ENCRYPTED]') . "\n";
    } else {
        echo "  $key: " . (empty($value) ? '[EMPTY]' : $value) . "\n";
    }
}

echo "\n3. Testing validation logic:\n";

if ($settings['provider'] === 'smtp') {
    if (empty($settings['host']) || empty($settings['username'])) {
        echo "❌ VALIDATION FAILED: SMTP host and username are required\n";
    } else {
        echo "✅ VALIDATION PASSED: SMTP host and username are present\n";
    }
}

echo "\n4. BEFORE FIX vs AFTER FIX:\n";
echo "BEFORE: Only used POST data (empty host/username)\n";
echo "AFTER:  Merges saved settings with POST data (populated host/username)\n";

echo "\n=== Fix Summary ===\n";
echo "✅ API test now retrieves saved email settings\n";
echo "✅ Merges saved settings with any new POST data\n";
echo "✅ Properly validates based on actual configuration\n";
echo "✅ Handles encrypted passwords correctly\n";
echo "✅ Should resolve 'SMTP host and username are required' error\n";
?>
