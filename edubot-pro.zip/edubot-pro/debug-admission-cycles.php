<?php
// Test to debug the admission cycles saving issue
// This test will help identify exactly where the problem is

// Mock WordPress functions
if (!function_exists('sanitize_text_field')) {
    function sanitize_text_field($str) { return trim(strip_tags($str)); }
}
if (!function_exists('update_option')) {
    function update_option($option, $value) {
        echo "UPDATE_OPTION: '$option' = " . print_r($value, true) . "\n";
        return true;
    }
}
if (!function_exists('wp_verify_nonce')) {
    function wp_verify_nonce($nonce, $action) { return true; }
}

echo "=== Debugging Admission Cycles Saving ===\n\n";

// Test 1: Simulate the form submission structure
echo "TEST 1: Form Data Structure\n";
echo "----------------------------\n";

$_POST = array(
    'submit' => 'Save Academic Configuration',
    'edubot_academic_nonce' => 'valid_nonce',
    'school_id' => '1',
    'academic_config' => array(
        'grade_system' => 'us-k12',
        'grade_systems' => array('us-k12'),
        'admission_cycles' => array(
            array(
                'name' => 'Fall 2024',
                'start_date' => '2024-09-01',
                'end_date' => '2024-12-15'
            ),
            array(
                'name' => 'Spring 2025',
                'start_date' => '2025-01-15',
                'end_date' => '2025-05-15'
            )
        )
    )
);

echo "Form POST data:\n";
print_r($_POST);

// Test 2: Simulate the save_academic_config method logic
echo "\nTEST 2: Save Method Logic\n";
echo "--------------------------\n";

// Check if form submission is detected
if (isset($_POST['submit']) && wp_verify_nonce($_POST['edubot_academic_nonce'], 'edubot_save_academic_config')) {
    echo "✓ Form submission detected correctly\n";
    
    // Check academic config processing
    if (isset($_POST['academic_config']) && is_array($_POST['academic_config'])) {
        echo "✓ Academic config data found\n";
        $config_data = $_POST['academic_config'];
        
        // Process admission cycles
        echo "\n--- Processing Admission Cycles ---\n";
        $admission_cycles = array();
        if (isset($config_data['admission_cycles']) && is_array($config_data['admission_cycles'])) {
            echo "✓ Found admission_cycles in config_data\n";
            echo "Raw admission cycles count: " . count($config_data['admission_cycles']) . "\n";
            
            foreach ($config_data['admission_cycles'] as $index => $cycle) {
                echo "Processing cycle #$index:\n";
                print_r($cycle);
                
                if (!is_array($cycle)) {
                    echo "  ✗ Skipped - not an array\n";
                    continue;
                }
                
                $name = sanitize_text_field($cycle['name'] ?? '');
                $start_date = sanitize_text_field($cycle['start_date'] ?? '');
                $end_date = sanitize_text_field($cycle['end_date'] ?? '');
                
                echo "  Sanitized name: '$name'\n";
                echo "  Sanitized start_date: '$start_date'\n";
                echo "  Sanitized end_date: '$end_date'\n";
                
                if (!empty($name) && strlen($name) <= 100) {
                    $admission_cycles[] = array(
                        'name' => $name,
                        'start_date' => $start_date,
                        'end_date' => $end_date
                    );
                    echo "  ✓ Added to admission_cycles array\n";
                } else {
                    echo "  ✗ Skipped - name empty or too long\n";
                }
            }
        } else {
            echo "✗ No admission_cycles found in config_data\n";
        }
        
        echo "\nFinal admission_cycles array:\n";
        print_r($admission_cycles);
        echo "Final count: " . count($admission_cycles) . "\n";
        
        // Simulate the save (our fixed version - always save)
        echo "\n--- Saving Admission Cycles ---\n";
        update_option('edubot_admission_cycles', $admission_cycles);
        echo "✓ Admission cycles saved using always-save logic\n";
        
    } else {
        echo "✗ No academic_config data found in POST\n";
    }
} else {
    echo "✗ Form submission not detected\n";
    echo "Submit button: " . (isset($_POST['submit']) ? "FOUND" : "NOT FOUND") . "\n";
    echo "Nonce verification: " . (wp_verify_nonce($_POST['edubot_academic_nonce'] ?? '', 'edubot_save_academic_config') ? "PASSED" : "FAILED") . "\n";
}

// Test 3: Empty admission cycles
echo "\n\nTEST 3: Empty Admission Cycles\n";
echo "------------------------------\n";

$_POST['academic_config']['admission_cycles'] = array(); // Empty array

$config_data = $_POST['academic_config'];
$admission_cycles = array();

if (isset($config_data['admission_cycles']) && is_array($config_data['admission_cycles'])) {
    echo "✓ Empty admission_cycles array found\n";
    foreach ($config_data['admission_cycles'] as $cycle) {
        // This loop won't run for empty array
    }
}

echo "Final count for empty array: " . count($admission_cycles) . "\n";
update_option('edubot_admission_cycles', $admission_cycles);
echo "✓ Empty admission cycles saved (allows deletion)\n";

// Test 4: Check for conflicts with other save methods
echo "\n\nTEST 4: Checking for Method Conflicts\n";
echo "-------------------------------------\n";

echo "The form uses nonce: 'edubot_save_academic_config'\n";
echo "But there's another method that expects nonce: 'edubot_save_academic_settings'\n";
echo "These are different methods:\n";
echo "1. save_academic_config() - expects \$_POST['academic_config']['admission_cycles']\n";
echo "2. save_academic_settings() - expects \$_POST['admission_cycles'] directly\n";
echo "\n";
echo "If the wrong method is being called, it would explain the saving failure.\n";

echo "\n=== SUMMARY ===\n";
echo "✅ Form data structure is correct\n";
echo "✅ Save logic processes the data correctly\n";
echo "✅ Empty arrays are handled properly (allows deletion)\n";
echo "⚠️  Check which save method is actually being called in WordPress\n";
echo "⚠️  Verify the form submits to the correct handler\n";
echo "\nIf admission cycles still don't save, the issue is likely:\n";
echo "1. Wrong save method being called\n";
echo "2. Form not submitting properly\n";
echo "3. Nonce verification failing\n";
echo "4. PHP errors preventing execution\n";
?>
