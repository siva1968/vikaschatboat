<?php
/**
 * WordPress Email Settings Checker
 * Add this temporarily to your WordPress admin dashboard or run via WP-CLI
 */

// This script should be run from within WordPress context
// You can add this to your theme's functions.php temporarily or use WP-CLI

function debug_edubot_email_settings() {
    echo "<h3>EduBot Email Settings Debug</h3>";
    
    // Get all email-related options
    $email_options = array(
        'edubot_email_service' => get_option('edubot_email_service', 'not set'),
        'edubot_smtp_host' => get_option('edubot_smtp_host', 'not set'),
        'edubot_smtp_port' => get_option('edubot_smtp_port', 'not set'),
        'edubot_smtp_username' => get_option('edubot_smtp_username', 'not set'),
        'edubot_smtp_password' => get_option('edubot_smtp_password', 'not set'),
        'edubot_email_api_key' => get_option('edubot_email_api_key', 'not set'),
        'edubot_email_domain' => get_option('edubot_email_domain', 'not set'),
        'edubot_email_from_address' => get_option('edubot_email_from_address', 'not set'),
        'edubot_email_from_name' => get_option('edubot_email_from_name', 'not set')
    );
    
    echo "<pre>";
    foreach ($email_options as $key => $value) {
        if (strpos($key, 'password') !== false || strpos($key, 'api_key') !== false) {
            echo "{$key}: " . ($value !== 'not set' ? '[SET - ' . strlen($value) . ' chars]' : 'not set') . "\n";
        } else {
            echo "{$key}: {$value}\n";
        }
    }
    echo "</pre>";
    
    // Test password decryption if password is set
    $password = get_option('edubot_smtp_password', '');
    if (!empty($password)) {
        echo "<h4>Password Decryption Test:</h4>";
        echo "<p>Encrypted password length: " . strlen($password) . " characters</p>";
        
        try {
            // Check if EduBot_Security_Manager class exists
            if (class_exists('EduBot_Security_Manager')) {
                $security_manager = new EduBot_Security_Manager();
                $decrypted = $security_manager->decrypt_api_key($password);
                echo "<p style='color: green;'>✅ Password decryption successful! Decrypted length: " . strlen($decrypted) . " characters</p>";
            } else {
                echo "<p style='color: red;'>❌ EduBot_Security_Manager class not found!</p>";
            }
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Password decryption failed: " . $e->getMessage() . "</p>";
        }
    }
    
    // Test API integrations class
    echo "<h4>API Integrations Test:</h4>";
    if (class_exists('EduBot_API_Integrations')) {
        echo "<p style='color: green;'>✅ EduBot_API_Integrations class found</p>";
        
        $api_integrations = new EduBot_API_Integrations();
        
        // Test settings
        $test_settings = array(
            'provider' => 'smtp',
            'host' => 'smtp.zeptomail.in',
            'port' => 587,
            'username' => 'emailapikey',
            'password' => 'PHtE6r0KRL/ijzJ+oUBV7ffpF8KmNYMt+r9uKghG5YsQA6AKSk1VqIt6lzDm+hciVKQQEf7Pm4I64r+fsrjTJzq5YWcdWGqyqK3sx/VYSPOZsbq6x00Zs1gScEPVU4Lret5u0CLfvN3YNA==',
            'from_address' => 'noreply@epistemo.in',
            'from_name' => 'EduBot Test'
        );
        
        // Decrypt the password first
        try {
            if (class_exists('EduBot_Security_Manager')) {
                $security_manager = new EduBot_Security_Manager();
                $test_settings['password'] = $security_manager->decrypt_api_key($test_settings['password']);
                echo "<p>Password decrypted for test</p>";
            }
        } catch (Exception $e) {
            echo "<p style='color: red;'>Failed to decrypt test password: " . $e->getMessage() . "</p>";
        }
        
        echo "<p>Testing email connection with settings:</p>";
        echo "<pre>";
        print_r(array_merge($test_settings, array('password' => '[REDACTED]')));
        echo "</pre>";
        
        $result = $api_integrations->test_email_connection($test_settings);
        echo "<h4>Test Result:</h4>";
        echo "<pre>";
        print_r($result);
        echo "</pre>";
        
    } else {
        echo "<p style='color: red;'>❌ EduBot_API_Integrations class not found!</p>";
    }
}

// Instructions for use
echo "
<div style='background: #f0f0f0; padding: 15px; border: 1px solid #ddd; margin: 20px 0;'>
<h3>How to use this debug script:</h3>
<ol>
    <li><strong>WordPress Admin Method:</strong><br>
        - Copy this entire PHP code<br>
        - Go to WordPress Admin → Appearance → Theme Editor<br>
        - Edit functions.php<br>
        - Add this code at the bottom (before closing ?>)<br>
        - Add this line: <code>add_action('wp_footer', 'debug_edubot_email_settings');</code><br>
        - Visit any page on your site to see the debug output
    </li>
    <li><strong>WP-CLI Method (if available):</strong><br>
        - Save this as debug-email.php in your WordPress root<br>
        - Run: <code>wp eval-file debug-email.php</code>
    </li>
    <li><strong>Direct Plugin Method:</strong><br>
        - Add this to your plugin's admin page temporarily<br>
        - Call the function in your admin dashboard
    </li>
</ol>
<p><strong>After testing, remove this debug code!</strong></p>
</div>
";
?>
