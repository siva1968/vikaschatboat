<?php

echo "=== ZeptoMail API Test ===\n\n";

$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.zeptomail.in/v1.1/email",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => '{
"from": { "address": "noreply@epistemo.in"},
"to": [{"email_address": {"address": "prasad@sampoornadigi.com","name": "prasad"}}],
"subject":"Test Email via ZeptoMail API",
"htmlbody":"<div><b>Test email sent successfully via ZeptoMail API.</b><br>Timestamp: ' . date('Y-m-d H:i:s') . '</div>"
}',
    CURLOPT_HTTPHEADER => array(
        "accept: application/json",
        "authorization: Zoho-enczapikey PHtE6r0KRL/ijzJ+oUBV7ffpF8KmNYMt+r9uKghG5YsQA6AKSk1VqIt6lzDm+hciVKQQEf7Pm4I64r+fsrjTJzq5YWcdWGqyqK3sx/VYSPOZsbq6x00Zs1gScEPVU4Lret5u0CLfvN3YNA==",
        "cache-control: no-cache",
        "content-type: application/json",
    ),
));

echo "📧 Sending test email via ZeptoMail API...\n";
echo "From: noreply@epistemo.in\n";
echo "To: prasad@sampoornadigi.com\n";
echo "Subject: Test Email via ZeptoMail API\n\n";

$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$err = curl_error($curl);

curl_close($curl);

echo "HTTP Response Code: {$http_code}\n";

if ($err) {
    echo "❌ cURL Error: " . $err . "\n";
} else {
    echo "📨 API Response:\n";
    echo $response . "\n\n";
    
    $decoded = json_decode($response, true);
    if ($decoded) {
        if ($http_code == 200 || $http_code == 201) {
            echo "✅ SUCCESS: Email sent successfully!\n";
            echo "Status: " . ($decoded['message'] ?? 'N/A') . "\n";
            if (isset($decoded['data'])) {
                echo "Response: " . ($decoded['data'][0]['message'] ?? 'N/A') . "\n";
                echo "Code: " . ($decoded['data'][0]['code'] ?? 'N/A') . "\n";
            }
            if (isset($decoded['request_id'])) {
                echo "Request ID: " . $decoded['request_id'] . "\n";
            }
        } else {
            echo "❌ FAILED: HTTP {$http_code}\n";
            if (isset($decoded['message'])) {
                echo "Error: " . $decoded['message'] . "\n";
            }
            if (isset($decoded['details'])) {
                echo "Details: " . print_r($decoded['details'], true) . "\n";
            }
        }
    }
}

echo "\n=== Test Complete ===\n";
?>
